// Global Variables
LDAP *ld = NULL;
char *ldapUserName = NULL;
char *ldapPassword = NULL;

// Function prototype declarations
EXTERN int Ldap_tcl_Init _ANSI_ARGS_((Tcl_Interp * interp));

int LDAPSearchCmd(ClientData clientData, Tcl_Interp *interp,
          int argc, char *argv[]);
int LDAPAllInOneSearchCmd(ClientData clientData, Tcl_Interp *interp,
          int argc, char *argv[]);
int LDAPSetNamePasswordCmd(ClientData clientData, Tcl_Interp *interp,
          int argc, char *argv[]);
int LDAPConnectCmd(ClientData clientData, Tcl_Interp *interp,
          int argc, char *argv[]);
int LDAPDisconnectCmd(ClientData clientData, Tcl_Interp *interp,
          int argc, char *argv[]);