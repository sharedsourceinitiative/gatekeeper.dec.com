
  This directory contains the current documentation for the plugin
  at the time the release was built (Jan 16th 1998). Some files are
  plain text files, some are in the unix manual pages format.

  To get the latest and more up to date documentation about the plugin
  as well as to get the documentation in HTML format, please visit

            http://sunscript.sun.com/plugin/

