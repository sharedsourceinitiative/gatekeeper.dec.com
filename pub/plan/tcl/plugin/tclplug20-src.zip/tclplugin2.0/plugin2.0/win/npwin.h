/*
 * npWin.h --
 *
 *	Windows specific #include directives.
 *
 * CONTACT:		sunscript-plugin@sunscript.sun.com
 *
 * AUTHORS:		Jacob Levy			Laurent Demailly
 *			jyl@eng.sun.com			demailly@eng.sun.com
 *			jyl@tcl-tk.com			L@demailly.com
 *
 * Please contact us directly for questions, comments and enhancements.
 *
 * Copyright (c) 1996-1997 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * SCCS: @(#) npwin.h 1.7 97/09/26 07:36:48
 */

#ifndef _NPWIN
#define _NPWIN

#include "tkWin.h"

#ifndef	F_OK
#define	F_OK	0
#endif

#endif /* _NPWIN */
