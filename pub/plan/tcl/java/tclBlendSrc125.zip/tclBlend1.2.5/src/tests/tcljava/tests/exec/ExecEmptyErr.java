/*
 * ExecEmptyErr.java --
 *
 * jacl/tests/exec/ExecEmptyErr.java
 *
 * Copyright (c) 1998 by Moses DeJong
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * RCS: @(#) $Id: ExecEmptyErr.java,v 1.1 1999/05/10 04:09:03 dejong Exp $
 *
 */

package tests.exec;

public class ExecEmptyErr {
  public static void main(String[] argv) {
    System.exit(-1);
  }
}

