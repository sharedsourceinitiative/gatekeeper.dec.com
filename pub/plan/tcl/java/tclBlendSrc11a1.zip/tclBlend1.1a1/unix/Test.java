//This class is used as a simple test for the compiler and runtime

public class Test {
  public static void main(String[] argv) {
    //do nothing just exit with a valid result
    System.exit(0);
  }
}
