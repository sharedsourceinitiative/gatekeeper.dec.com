package tests.invoke;

interface IntC {
    String getStringC();
}
