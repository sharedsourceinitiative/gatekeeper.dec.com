/*
 * JavaGetInterpCmd.java --
 *
 *	Implements the built-in "java::getinterp" command.
 *
 * Copyright (c) 1997 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 * SCCS: @(#) JavaGetInterpCmd.java 1.2 97/11/07 17:17:58
 */

package tcl.lang;

/*
 * Implements the built-in "java::getinterp" command.
 */

class JavaGetInterpCmd implements Command {


/*----------------------------------------------------------------------
 *
 * cmdProc --
 *
 * 	This procedure is invoked to process the "java::getInterp" Tcl
 * 	command. See the user documentation for details on what it
 * 	does.
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	A standard Tcl result is stored in the interpreter.
 *
 *----------------------------------------------------------------------
 */

public void
cmdProc(
    Interp interp,			// Current interpreter.
    TclObject argv[])			// Argument list.
throws
    TclException			// A standard Tcl exception.
{
    interp.setResult(ReflectObject.newInstance(interp, interp));
}

} // end JavaGetInterpCmd
