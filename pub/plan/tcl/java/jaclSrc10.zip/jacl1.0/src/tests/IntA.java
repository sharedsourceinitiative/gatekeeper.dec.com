package tests.invoke;

public interface IntA {
    public String getStringA();
}
