/*
 * NoEventBean --
 *
 *	A Bean that has no events. Used to test the java::bind command.
 *
 * Copyright (c) 1997 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 * SCCS: @(#) NoEventBean.java 1.1 97/12/02 13:12:39
 */

package tcl.lang;

import java.util.*;

public class NoEventBean {

public NoEventBean() {}


} // end TesterBean
