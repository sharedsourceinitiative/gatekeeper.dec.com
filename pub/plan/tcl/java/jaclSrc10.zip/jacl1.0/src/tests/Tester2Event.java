/*
 * Tester2Event.java --
 *
 *	This is an event object that tests the java::bind and java::event
 *	commands.
 *
 * Copyright (c) 1997 Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 * SCCS: @(#) Tester2Event.java 1.1 97/12/02 13:16:04
 */

package tcl.lang;

import java.util.*;

public class Tester2Event extends EventObject {

public Tester2Event(Object source)
{
    super(source);
}

} // end Tester2Event
