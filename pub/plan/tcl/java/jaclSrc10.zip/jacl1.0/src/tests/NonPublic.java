/*
 * This class is used to test whether Invoke.tclTest is handled correctly.
 * See tests/common/Invoke.test.
 */

package tcl.lang;

class NonPublic {
    public static int field = 0;

    public NonPublic() {

    }
}
