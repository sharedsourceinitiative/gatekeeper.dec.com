// this class is only used to make the compiler happy when
// no sources are provided in regex, it is also used to
// make the build rule happy is case there are no compiled
// regexp classes in the jacl/tcl/regex directory
package tcl.regex;
class Placeholder {
	private Placeholder() {}
}
