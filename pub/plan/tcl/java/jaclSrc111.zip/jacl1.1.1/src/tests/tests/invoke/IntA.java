/* 
 * IntA.java --
 *
 *
 * Copyright (c) 1997 by Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * RCS: @(#) $Id: IntA.java,v 1.1.1.1 1998/10/14 21:09:12 cvsadmin Exp $
 *
 */

package tests.invoke;

public interface IntA {
    public String getStringA();
}

