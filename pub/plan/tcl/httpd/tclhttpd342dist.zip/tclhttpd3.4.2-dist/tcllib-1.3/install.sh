#!/bin/sh
TCLINSTALL=$1
if [ "${TCLINSTALL}x" = "x" ] ; then \
   TCLINSTALL=/usr/local
fi
here=`pwd`
cd $TCLINSTALL
TCLINSTALL=`pwd`
cd $here
echo Installing tcllib 1.3 to $TCLINSTALL
if [ ! -d $TCLINSTALL/lib/tcllib1.3 ] ; then \
    mkdir -p $TCLINSTALL/lib/tcllib1.3 ; \
fi
if [ ! -d $TCLINSTALL/man/mann ] ; then \
    mkdir -p $TCLINSTALL/man/mann ; \
fi
if [ ! -d $TCLINSTALL/lib/tcllib1.3/htmldoc ] ; then \
    mkdir -p $TCLINSTALL/lib/tcllib1.3/htmldoc ; \
fi
cp -f pkgIndex.tcl    $TCLINSTALL/lib/tcllib1.3
cp -f doc/nroff/*.n   $TCLINSTALL/man/mann                     2> /dev/null ; \
cp -f doc/html/*.html $TCLINSTALL/lib/tcllib1.3/htmldoc 2> /dev/null ; \
cd modules
for j in base64 calendar cmdline comm control crc csv counter doctools dns exif struct fileutil ftp ftpd javascript html irc math md5 mime ncgi nntp pop3 pop3d profiler smtpd textutil uri log htmlparse report sha1 stooop ; do \
    if [ ! -d $TCLINSTALL/lib/tcllib1.3/$j ] ; then \
        mkdir $TCLINSTALL/lib/tcllib1.3/$j ; \
    fi; \
    cp -f $j/*.tcl    $TCLINSTALL/lib/tcllib1.3/$j 2>/dev/null; \
    if [ -f $j/tclIndex ] ; then \
        cp -f $j/tclIndex $TCLINSTALL/lib/tcllib1.3/$j ; \
    fi ; \
done
