This directory is protected by means Digest Authentication
