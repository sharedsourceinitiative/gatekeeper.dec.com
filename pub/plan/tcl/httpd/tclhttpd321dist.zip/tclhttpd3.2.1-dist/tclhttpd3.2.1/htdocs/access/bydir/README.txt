You should only be able to read this if you know the password.
