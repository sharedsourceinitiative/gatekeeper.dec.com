#!/bin/sh
TCLINSTALL=$1
if [ "${TCLINSTALL}x" = "x" ] ; then \
   TCLINSTALL=/usr/local
fi
if [ ! -d $TCLINSTALL/lib/tcllib0.8 ] ; then \
    mkdir -p $TCLINSTALL/lib/tcllib0.8 ; \
fi
if [ ! -d $TCLINSTALL/man/mann ] ; then \
    mkdir -p $TCLINSTALL/man/mann ; \
fi
cp -f pkgIndex.tcl $TCLINSTALL/lib/tcllib0.8
for j in base64 cmdline counter struct fileutil ftp ftpd javascript html math mime ncgi nntp pop3 profiler textutil uri ; do \
    if [ ! -d $TCLINSTALL/lib/tcllib0.8/$j ] ; then \
        mkdir $TCLINSTALL/lib/tcllib0.8/$j ; \
    fi; \
    cp -f $j/*.tcl $TCLINSTALL/lib/tcllib0.8/$j ; \
    cp -f $j/*.n   $TCLINSTALL/man/mann ; \
done
