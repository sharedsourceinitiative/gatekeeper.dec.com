This directory has a .htaccess that allows "from all"
