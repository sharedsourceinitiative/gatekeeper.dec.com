To build on windows, set up your Cygwin environment as described in
http://dev.scriptics.com/doc/tea/windows.html
then run the CONFIG script here from the Cygwin bash shell.
	sh CONFIG
That will create a Makefile which you use to run "make" and "make install"

Alternatively, you can use the project and nmake files in the
vc directory.  You'll have to edit those files to according
to the vc/README file.
