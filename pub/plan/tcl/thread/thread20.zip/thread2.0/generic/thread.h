/* RCS: @(#) $Id: thread.h,v 1.2 2000/04/11 23:10:54 welch Exp $ */

#define THREAD_MAJOR_VERSION  2
#define THREAD_MINOR_VERSION  0
#define THREAD_VERSION   "2.0"
