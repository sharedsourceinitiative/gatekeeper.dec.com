/*
 * wctype.h --
 *
 *	Regexp package file:  fake wctype.h for char
 *
 * Copyright (c) 1998 Henry Spencer
 * Copyright (c) 1998 by Sun Microsystems, Inc.
 *
 * See the file "license.terms" for information on usage and redistribution
 * of this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 * SCCS: @(#) wctype.h 1.7 98/01/21 22:14:31
 */

#ifndef _WCTYPE

#ifndef _WINT_T
#   define _WINT_T
    typedef int wint_t;
#endif

#undef WEOF
#undef WCHAR_MIN
#undef WCHAR_MAX

#define WEOF	  -1
#define WCHAR_MIN 0x0000
#define WCHAR_MAX 0xffff

#undef iswalnum
#undef iswalpha
#undef iswdigit
#undef iswspace

#define	iswalnum(x)	TclUniCharIsAlnum(x)
#define	iswalpha(x)	TclUniCharIsAlpha(x)
#define	iswdigit(x)	TclUniCharIsDigit(x)
#define	iswspace(x)	TclUniCharIsSpace(x)

#undef wcslen
#undef wcsncmp

#define	wcslen	TclUniCharLen
#define	wcsncmp	TclUniCharNcmp

#define _WCTYPE
#endif	/* !_WCTYPE */
