/*
 * graphutil.c
 *
 * HTTP Out-of-order processing simulation:
 * declarations for utility functions for graph-plotting
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: graphutil.h,v $
 * Revision 1.6  2002/01/16  01:03:39  mogul
 * Added GUtil_BumpWeightedDistrib()
 *
 * Revision 1.5  2001/12/28  22:58:40  mogul
 * Supports PctCDF
 *
 * Revision 1.4  2001/12/27  22:45:32  mogul
 * Added DD_LOGX
 *
 * Revision 1.3  2001/12/27  19:00:32  mogul
 * Portability.
 *
 * Revision 1.2  2001/12/11  01:57:40  mogul
 * Added copyright notice
 *
 * Revision 1.1  2001/12/07  01:20:36  mogul
 * Initial revision
 *
 *
 */

/*
 * We store information during Metric_Update*() calls so that
 * it is easy to compute mean & std. dev. later on
 */
typedef struct distrib_stats_st {
	long	n;		/* number of samples */
	ulong64	sum_x;		/* running total of sample values */
	double	sum_x_squared;	/* running total of squared sample values */
} distrib_stats;

/*
 * Each distribution is represented as a "long *" (see distrib.h).
 * Space is dynamically allocated during initialization; here is
 * where we hold all of the pointers.
 */
typedef struct distrib_descrip_st {
	char *distrib_name;	/* name (x-axis label) */
	long *distrib_data;	/* representation */
	int   is_log;		/* true for log-scale distributions */
	int   continues;	/* more curves for this graph */
	int   xlim;		/* max x limit for graph (< 0 => no limit) */
	int   index;		/* just for consistency checking */
	
	/* following fields are NOT initialized at compile time*/
	distrib_stats	stats;	/* see above */
} distrib_descrip;

/* for is_log field */
#define	DD_LIN		0
#define	DD_LOGBOTH	1	/* both axes are log-scale */
#define	DD_LOGY		2	/* only y-axis is log-scale */
#define	DD_LOGX		3	/* only x-axis is log-scale */

/* for continues field */
#define	DD_LAST	0
#define	DD_CONT	1

/* for cumulative argument to GUtil_PrintAllDistribs/GUtil_PrintGraphHeader */
typedef enum { PDF, CDF, PctCDF } CumType;

void GUtil_InitDistribs(distrib_descrip *distribs, int ndistrib);
void GUtil_PrintGraphHeader(FILE *outf, int is_log, const char *distname,
                CumType cumulative, int xlim);
void GUtil_PrintGraphLineType(FILE *outf, int linetype);
void GUtil_PrintGraphBreak(FILE *outf);
void GUtil_PrintLogKey(FILE *outf, long *d_data, char *d_name, int offset,
			int xlim);
void GUtil_PrintLinKey(FILE *outf, long *d_data, char *d_name, int offset,
			int xlim);
void GUtil_Statistics(FILE *outf, distrib_descrip *ddp);
void GUtil_PrintAllDistribs(FILE *outf, CumType cumulative);
void GUtil_BumpDistrib(int distrib_index, ulong64 dataval);
void GUtil_BumpWeightedDistrib(int distrib_index, ulong64 dataval,
	ulong64 weight);
int PctRatio(long64 vnew, long64 vorig);
