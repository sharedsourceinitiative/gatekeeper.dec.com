/*
 * logdistrib.c
 *
 * Functions for manipulating logarithmic distributions
 *
 * Jeffrey Mogul
 *
 * 12 January 1999 - Created
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: logdistrib.c,v $
 * Revision 1.6  2002/01/15  23:16:04  mogul
 * Portability to FreeBSD (thanks to Alec Wolman)
 *
 * Revision 1.5  2001/12/28  22:59:37  mogul
 * Support for PctCumDistrib printing.
 *
 * Revision 1.4  2001/12/12  00:56:44  mogul
 * Added computation of medians
 *
 * Revision 1.3  2001/12/11  01:57:40  mogul
 * Added copyright notice
 *
 * Revision 1.2  2001/11/20  22:46:52  mogul
 * *** empty log message ***
 *
 * Revision 1.1  2001/08/22  19:45:45  mogul
 * Initial revision
 *
 */

#include <stdio.h>
#include <math.h>
#include "portability.h"
/*#include <ctype.h> */
#include "distrib.h"

int divperdecade = 20;
int maxdecades = 12;
int maxindex;

long *InitLogDistrib()
{
	long *distrib;
	int allocbytes;
	
	maxindex = divperdecade * maxdecades;

	allocbytes = sizeof(long) * (maxindex + 1);
	distrib = (long *)malloc(allocbytes);
	if (distrib == NULL) {
	    perror("InitLogDistrib");
	    exit(1);
	}
	bzero(distrib, allocbytes);
	return(distrib);
}

void UpdateLogDistrib(long *distrib, int xval)
{
	double l10val;
	int idx;
	
	/* avoid negative log values */
	if (xval < 1)
	    xval = 1;

	l10val = log10f(xval + 0.0);
	idx = l10val * divperdecade;
	if (idx > maxindex)
	    idx = maxindex;
	distrib[idx]++;
}

/* byte-weighted distribution */
void UpdateLogDistribBW(long *distrib, int xval, int len)
{
	double l10val;
	int idx;
	
	/* avoid negative log values */
	if (xval < 1)
	    xval = 1;

	l10val = log10f(xval + 0.0);
	idx = l10val * divperdecade;
	if (idx > maxindex)
	    idx = maxindex;
	distrib[idx] += len;
}

void PrintLogDistrib(FILE *outf, long *distrib)
{
	int i;
	float len;
	float sidx;

	for (i = 0; i <= maxindex; i++) {
	    if (distrib[i]) {
		sidx = (i + 0.0)/divperdecade;
		len = powf(10.0, sidx);
		fprintf(outf, "%.2f %ld\n", len, distrib[i]);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void PrintLogCumDistrib(FILE *outf, long *distrib)
{
	int i;
	float len;
	float sidx;
	long sum;

	sum = 0;
	for (i = 0; i <= maxindex; i++) {
	    if (distrib[i]) {
		sidx = (i + 0.0)/divperdecade;
		len = powf(10.0, sidx);
		sum += distrib[i];
		fprintf(outf, "%.2f %ld\n", len, sum);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void PrintLogPctCumDistrib(FILE *outf, long *distrib)
{
	int i;
	float len;
	float sidx;
	long sum;
	long total;

	total = 0;
	for (i = 0; i <= maxindex; i++) {
	    total += distrib[i];
	}

	sum = 0;
	for (i = 0; i <= maxindex; i++) {
	    if (distrib[i]) {
		sidx = (i + 0.0)/divperdecade;
		len = powf(10.0, sidx);
		sum += distrib[i];
		fprintf(outf, "%.2f %f\n", len, (sum * 100.0)/total);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void
BBoxLogDistrib(long *distrib,
	long *xminp, long *xmaxp, long *yminp, long *ymaxp,
	long *firstp, long *totp)
{
	long xmax, xmin, ymax, ymin;
	long tot;
	int i;
	long v;
	float len;
	float sidx;
	int firstset = 0;
	
	xmax = -1;
	xmin = MAXLONG;
	ymax = -1;
	ymin = MAXLONG;
	tot = 0;
	
	for (i = 0; i <= maxindex; i++) {
	    v = distrib[i];
	    tot += v;
	    if (v) {
		if (firstset == 0) {
		    *firstp = tot;
		    firstset = 1;
		}
		sidx = (i + 0.0)/divperdecade;
		len = powf(10.0, sidx);
		if (len < xmin)
		    xmin = len;
		if (len > xmax)
		    xmax = len;
		if (v < ymin)
		    ymin = v;
		if (v > ymax)
		    ymax = v;
	    }
	}
	
	*xminp = xmin;
	*xmaxp = xmax;
	*yminp = ymin;
	*ymaxp = ymax;
	*totp = tot;
}

/*
 * Compute median of distribution.  Uses brute-force approach
 * Assumptions:
 *	number of samples fits into an unsigned long
 */
float
LogDistribMedian(long *distrib)
{
	unsigned long tot;
	unsigned long sum;
	float len;
	float sidx;
	int i;
	long v;
	
	/*
	 * Step 1: find out how many samples we have
	 */
	tot = 0;
	for (i = 0; i <= maxindex; i++) {
	    tot += distrib[i];
	}
	
	/*
	 * Step 2: count samples again, until we've found half of them
	 */
	sum = 0;
	for (i = 0; i <= maxindex; i++) {
	    sum += distrib[i];
	    if (sum >= (tot/2)) {
		/* Convert i from log space to sample space */
		sidx = (i + 0.0)/divperdecade;
		len = powf(10.0, sidx);
		return(len);
	    }
	}
	
	fprintf(stderr, "LogDistribMedian: should't happen\n");
	abort();
}
