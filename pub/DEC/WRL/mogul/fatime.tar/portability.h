/*
 * portability.h
 *
 * Useful definitions for portability
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: portability.h,v $
 * Revision 1.6  2002/01/16  23:15:35  mogul
 * Supports OpenBSD/FreeBSD style of printf("%lld") for long long ints.
 * OpenBSD support.
 *
 * Revision 1.5  2002/01/15  23:16:04  mogul
 * Portability to FreeBSD (thanks to Alec Wolman)
 *
 * Revision 1.4  2001/12/28  23:01:36  mogul
 * 32-bit types.
 *
 * Revision 1.3  2001/12/12  18:54:16  mogul
 * Added a preprocessor symbol, for convenience.
 *
 * Revision 1.2  2001/12/11  01:57:40  mogul
 * Added copyright notice
 *
 * Revision 1.1  2001/12/11  01:49:41  mogul
 * Initial revision
 *
 */

#ifndef	_PORTABILITY_H_
#define	_PORTABILITY_H_

#if defined(linux) || defined(__FreeBSD__) || defined(__OpenBSD__)
typedef unsigned char   uchar;
#endif

#if defined(__FreeBSD__)
typedef unsigned long	ulong;
#endif

#if defined(__FreeBSD__) || defined(__OpenBSD__)
#include <limits.h>
#define MAXLONG LONG_MAX
#define MAXINT INT_MAX
#else
#include <values.h>
#endif

/*
 * Deal with 64 bit values on either 32-bit or 64-bit hardware
 * NOTE: this is probably the wrong #ifdef to use, since there
 * are non-Alpha systems with 64-bit longs.
 */
#ifdef	__ALPHA
typedef long			long64;
typedef unsigned long		ulong64;
typedef int			long32;
typedef unsigned int		ulong32;
#else
typedef long long		long64;
typedef unsigned long long	ulong64;
typedef long			long32;
typedef unsigned long		ulong32;
#define	printfLL
#endif

/*
 * Everyone has a different way to printf() a 64-bit integer (grr)
 */
#ifdef	linux
/* %Ld or %Lu */
#define	printf_L
#endif

#if defined(__FreeBSD__) || defined(__OpenBSD__)
/* %lld or %llu */
#define	printf_ll
#endif

#if defined(__osf__)
/* %ld or %lu */
#define	printf_l
#endif

#endif	/* _PORTABILITY_H_ */
