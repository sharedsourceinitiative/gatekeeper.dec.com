/*
 * dofiledir.c
 *
 * Deal with a file or directory
 *
 * Part of: fatime program;
 * Measure file access times, for various phases of accessing a file,
 * across a set of files.
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: dofiledir.c,v $
 * Revision 1.9  2002/02/01  22:21:06  mogul
 * *** empty log message ***
 *
 * Revision 1.8  2002/01/31  22:31:51  mogul
 * Added -n flag
 *
 * Revision 1.7  2002/01/31  22:23:34  mogul
 * Support for -t flag
 *
 * Revision 1.6  2002/01/26  00:06:43  mogul
 * Portability fixes
 *
 * Revision 1.6  2002/01/26  00:06:43  mogul
 * Portability fixes
 *
 * Revision 1.5  2001/12/11  18:59:11  mogul
 * Added copyright.
 *
 * Revision 1.4  2001/12/10  19:43:10  mogul
 * Better error/debugging printouts
 *
 * Revision 1.3  2001/12/07  00:42:08  mogul
 * Compute some delta times.
 *
 * Revision 1.2  2001/12/04  01:17:04  mogul
 * Checkpoint.
 *
 * Revision 1.1  2001/12/04  00:31:13  mogul
 * Initial revision
 *
 *
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <dirent.h>
#include <errno.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/resource.h>

#include "portability.h"
#include "graphutil.h"
#include "globals.h"

int filecount_all = 0;
int filecount_reg = 0;
int filecount_dir = 0;
int filecount_special = 0;
int filecount_symlink = 0;
int open_failed = 0;
int firstread_failed = 0;
int lastread_failed = 0;
int FSisNFS_failed = 0;

/* Largest rational buffer size */
#define	BIGBUFSIZE	(1024*1024)

static int indent;	/* indentation level, for debugging */

static void
doindent(FILE *outf, int indent)
{
	int i;

	for (i = 0; i < indent; i++)
	    fputc(' ', outf);
}

int DoDir(char *dname);

/*
 * ToDo:
 *	actually count things like
 *		file size distribution
 *		file blocks distribution
 *		timings:
 *			stat
 *			open
 *			firstread
 *				single-block files
 *				multi-block files
 *			lastread
 *				single-block files
 *				multi-block files
 */

void myperror(char *message);

/*
 * Processes a single file or directory.
 *
 * Returns -1 for failure, +1 for success
 */

int
DoFileOrDir(char *fordname)
{
	ulong64 stat_ts;
	ulong64 statdone_ts;
	ulong64 stat_delta;
	ulong64 open_ts;
	ulong64 opendone_ts;
	ulong64 open_delta;
	ulong64 firstread_ts;
	ulong64 firstresult_ts;
	ulong64 firstread_delta;
	ulong64 lastresult_ts;
	ulong64 restoffile_delta;
	ulong64 stattolast_delta;
	struct stat sb;
	static databuf[BIGBUFSIZE];
	int fd;
	int to_read;
	int this_read;
	int res;
	int is_nfs;

	if (debug) {
	    doindent(stderr, indent);
	    fprintf(stderr, "DoFileOrDir(%s): ", fordname);
	}

	filecount_all++;
	if ((interimcount > 0) && ((filecount_all % interimcount) == 0)) {
	    DoOutputs();
	}

	stat_ts = now_usecs();
	if (lstat(fordname, &sb) < 0) {
	    myperror(fordname);
	    return(-1);
	}
	statdone_ts = now_usecs();
	
	switch (sb.st_mode & S_IFMT) {
	case S_IFREG:
	    /*
	     * Regular file; continue processing below
	     */
	    filecount_reg++;
	    break;

	case S_IFDIR:
	    /*
	     * Directory
	     */
	    filecount_dir++;
	    return(DoDir(fordname));
	    /* NOTREACHED */
	    break;

	case S_IFLNK:
	    filecount_symlink++;
	    /* NOTREACHED */
	    return(1);
	    break;	    

	default:
	    /* Special file of some sort; done with it */
	    filecount_special++;
	    return(1);		/* XXX or zero, to indicate "no files done"? */
	    break;
	}

	if (namesonly) {
	    fprintf(stdout, "%s %x/%d %o\n", fordname,
		sb.st_dev, sb.st_ino, sb.st_mode);
	    return(1);
	}

	/* Open the file for reading, & measure time taken */
	open_ts = now_usecs();
	fd = open(fordname, O_RDONLY);
	if (fd < 0) {
	    open_failed++;
	    if (debug) {
		fprintf(stderr, "open failed\n");
	    }
	    myperror(fordname);
	    return(-1);
	}
	opendone_ts = now_usecs();

	/* Read first block (only) of file */
	to_read = sb.st_size;
	this_read = to_read;
	if (this_read > sb.st_blksize)
	    this_read = sb.st_blksize; 
	if (this_read > BIGBUFSIZE)
	    this_read = BIGBUFSIZE;

	firstread_ts = now_usecs();
	res = read(fd, databuf, this_read);
	firstresult_ts = now_usecs();
	if (res < 0) {
	    close(fd);
	    firstread_failed++;
	    if (debug) {
		fprintf(stderr, "first read failed\n");
	    }
	    myperror(fordname);
	    return(-1);
	}
	to_read -= res;		/* update count of remaining bytes to read */
	
	/* Read rest of file */
	while (to_read > 0) {
	    this_read = to_read;
	    if (this_read > BIGBUFSIZE)
		this_read = BIGBUFSIZE;
	    
	    res = read(fd, databuf, this_read);
	    if (res < 0) {
		close(fd);
		lastread_failed++;
		if (debug) {
		    fprintf(stderr, "last read failed\n");
		}
		myperror(fordname);
		return(-1);
	    }
	    to_read -= res;
	}

	lastresult_ts = now_usecs();
	
	is_nfs = FSisNFS(fd);
	if (is_nfs < 0) {
	    FSisNFS_failed++;
	    if (debug) {
		fprintf(stderr, "FSisNFS failed\n");
	    }
	    myperror(fordname);
	    return(-1);
	}

	close(fd);

	stat_delta = statdone_ts - stat_ts;
	open_delta = opendone_ts - open_ts;
	firstread_delta = firstresult_ts - firstread_ts;
	restoffile_delta = lastresult_ts - firstresult_ts;
	stattolast_delta = lastresult_ts - stat_ts;

	Results_Update(is_nfs,
		stat_delta,
		open_delta,
		firstread_delta,
		restoffile_delta,
		stattolast_delta,
		sb.st_blocks,
		sb.st_size);

	if (debug) {
#ifdef	notdef
		/* not needed - Results_Update outputs \n if (debug) */
	    fprintf(stderr, "\n");
#endif
	}

	return(1);
}

/*
 * Recursively process a directory
 *
 * Returns -1 for failure, +1 for success
 */
int DoDir(char *dname)
{
	DIR *dirp;
	struct dirent *dp;
	char pathbuf[MAXPATHLEN];

	if (debug || debugDir) {
	    if (debug)
		fprintf(stderr, "\n");
	    doindent(stderr, indent);
	    fprintf(stderr, "DoDir(%s):\n", dname);
	    indent++;
	}

	dirp = opendir(dname);
	if (dirp == NULL) {
	    if (debug || debugDir) {
		fprintf(stderr, "\n");
		doindent(stderr, indent);
		fprintf(stderr, "opendir failed (%s): \n", dname);
		indent--;
	    }
	    myperror(dname);
	    return(-1);
	}
	
	errno = 0;
	for (dp = readdir(dirp); dp != NULL; dp = readdir(dirp)) {
	    /* Skip "." and ".." entries */
	    if (strcmp(dp->d_name, ".") == 0)
		continue;
	    if (strcmp(dp->d_name, "..") == 0)
		continue;
	    sprintf(pathbuf, "%s/%s", dname, dp->d_name);
	    DoFileOrDir(pathbuf);
	    errno = 0;
	}

	if (errno > 0) {
	    if (debug || debugDir) {
		fprintf(stderr, "\n");
		doindent(stderr, indent);
		fprintf(stderr, "readdir failed (%s): \n", dname);
		indent--;
	    }
	    myperror(dname);
	    closedir(dirp);
	    return(-1);
	}

	closedir(dirp);

	if (debug || debugDir) {
	    indent--;
	    doindent(stderr, indent);
	    fprintf(stderr, "Done(%s): \n", dname);
	}

	return(1);	/* XXX or recursive count of files processed? */
}

void
PrintCounters(FILE *outf)
{
	fprintf(outf, "# filecount_all %d\n", filecount_all);
	fprintf(outf, "# filecount_reg %d\n", filecount_reg);
	fprintf(outf, "# filecount_dir %d\n", filecount_dir);
	fprintf(outf, "# filecount_special %d\n", filecount_special);
	fprintf(outf, "# filecount_symlink %d\n", filecount_symlink);
	fprintf(outf, "# open_failed %d\n", open_failed);
	fprintf(outf, "# firstread_failed %d\n", firstread_failed);
	fprintf(outf, "# lastread_failed %d\n", lastread_failed);
	fprintf(outf, "# FSisNFS_failed %d\n", FSisNFS_failed);
}

/*
 * Like perror(), but silent for errors that we can normally ignore
 * in this program:
 *	EACCES	Permission denied
 *	ELOOP	Too many levels of symbolic link
 *	ENOENT	No such file or directory
 */
void
myperror(char *message)
{
	switch (errno) {
	    case EACCES:
	    case ELOOP:
	    case ENOENT:
		if (allperrors == 0)
		    return;
	    	break;
	    default:
	    	break;
	}
	
	perror(message);
}

