/*
 * fatime.c
 *
 * Measure file access times, for various phases of accessing a file,
 * across a set of files.
 *
 * Usage:
 *	fatime [options] dir1 [dir2 ...]
 *
 *		-a	print ALL perror messages
 *		-c filename	CDF output to filename
 *		-d	debug output
 *		-D	debug output, directory names only
 *		-e	print execution stats (on stderr)
 *		-m size	sets assumed mean HTTP response body size (bytes)
 *		-n	prints names only (stdout), doesn't read files
 *		-p filename	PDF output to filename
 *		-P filename	percent-CDF output to filename
 *		-s	output statistics (counters) to stdout
 *		-t count	interim output every "count" files
 *		-v	verbose output
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: fatime.c,v $
 * Revision 1.9  2002/01/31  22:31:51  mogul
 * Added -n flag
 *
 * Revision 1.8  2002/01/31  22:23:34  mogul
 * Support for -t flag
 *
 * Revision 1.7  2002/01/26  00:07:42  mogul
 * Portability
 * -P flag
 *
 * Revision 1.6  2002/01/10  19:33:38  mogul
 * added -m option.
 *
 * Revision 1.5  2001/12/11  18:59:53  mogul
 * Added copyright.
 *
 * Revision 1.4  2001/12/11  01:58:38  mogul
 * Added some more flags.
 *
 * Revision 1.3  2001/12/04  01:17:04  mogul
 * Checkpoint.
 *
 * Revision 1.2  2001/12/04  00:31:13  mogul
 * *** empty log message ***
 *
 * Revision 1.1  2001/12/03  22:58:30  mogul
 * Initial revision
 *
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/resource.h>

#include "portability.h"
#include "graphutil.h"
#include "globals.h"

int debug = 0;
int debugDir = 0;
int verbose = 0;
int execstats = 0;
int statsout = 0;
int allperrors = 0;
int namesonly = 0;

int interimcount = 0;
int assumedmeanhttpsize = 10*1024;
	/*
	 * Values from various studies:
	 *	WebTV trace (Kelly, 2001):	13441
	 *	XXX add to this table?
	 */

struct timeval starttime;
char *startbrk;

FILE *PDFoutf = 0;
FILE *CDFoutf = 0;
FILE *PCDFoutf = 0;

void PrintExecutionStats(FILE *outf);

int main(int argc, char **argv)
{
	char *cmd = argv[0];
	int ch;
	extern int optind;
	extern char *optarg;
	static char PDFoutfname[MAXPATHLEN];
	static char CDFoutfname[MAXPATHLEN];
	static char PCDFoutfname[MAXPATHLEN];

	startbrk = sbrk(0);
	gettimeofday(&starttime, NULL);
	
	while ((ch = getopt(argc, argv, "ac:dDem:np:P:st:v")) != EOF) {
	
	    switch(ch) {
	    case 'a':
		allperrors++;
		break;
	    case 'c':
		strncpy(CDFoutfname, optarg, sizeof(CDFoutfname) - 1);
		CDFoutf = fopen(CDFoutfname, "w");
		if (CDFoutf == NULL) {
		    perror(CDFoutfname);
		    exit(1);
		}
		break;
	    case 'd':
		debug++;
		break;
	    case 'D':
		debugDir++;
		break;
	    case 'e':
		execstats++;
		break;
	    case 'm':
		assumedmeanhttpsize = atoi(optarg);
		break;
	    case 'n':
		namesonly++;
		break;
	    case 'p':
		strncpy(PDFoutfname, optarg, sizeof(PDFoutfname) - 1);
		PDFoutf = fopen(PDFoutfname, "w");
		if (PDFoutf == NULL) {
		    perror(PDFoutfname);
		    exit(1);
		}
		break;
	    case 'P':
		strncpy(PCDFoutfname, optarg, sizeof(CDFoutfname) - 1);
		PCDFoutf = fopen(PCDFoutfname, "w");
		if (PCDFoutf == NULL) {
		    perror(PCDFoutfname);
		    exit(1);
		}
		break;
	    case 's':
		statsout++;
		break;
	    case 't':
		interimcount = atoi(optarg);
		break;
	    case 'v':
		verbose++;
		break;
	    default:
		usage(cmd);
		/*NOTREACHED*/
	    }
	}
	argc -= optind;
	argv += optind;
	
	Results_InitDistribs();

	while (argc > 0) {
	    if (verbose > 0) {
		printf("reading %s:\n", argv[0]);
	    }

	    if (DoFileOrDir(argv[0]) < 0) {
		perror(argv[0]);
	    }

	    argc--;
	    argv++;
	}
	
	DoOutputs();
}

void
DoOutputs()
{
	if (PDFoutf) {
	    rewind(PDFoutf);
	    Results_PrintAllDistribs(PDFoutf, PDF);
	    PrintCounters(PDFoutf);
	    fflush(PDFoutf);
	}
	if (CDFoutf) {
	    rewind(CDFoutf);
	    Results_PrintAllDistribs(CDFoutf, CDF);
	    PrintCounters(CDFoutf);
	    fflush(CDFoutf);
	}
	if (PCDFoutf) {
	    rewind(PCDFoutf);
	    Results_PrintAllDistribs(PCDFoutf, PctCDF);
	    PrintCounters(PCDFoutf);
	    fflush(PCDFoutf);
	}

	if (statsout) {
	    PrintCounters(stdout);
	    fprintf(stdout, "\n");
	    fflush(stdout);
	}

	if (execstats) {
	    PrintExecutionStats(stderr);
	    fprintf(stderr, "\n");
	}
}

usage(char *cmd)
{
	fprintf(stderr, "usage:\n");
	fprintf(stderr,
"\t%s [-a|-d|-e|-v] [-c|-p file] [-m size] file/dir [file/dir ...]\n",
		 cmd);

	exit(1);
}

void PrintExecutionStats(FILE *outf)
{
        char *endbrk;
        struct timeval endtime;
        float delta;
        struct rusage ourusage;
        time_t now = time(0);

        endbrk = sbrk(0);
        gettimeofday(&endtime, NULL);

        fprintf(outf, "\n%s", ctime(&now));
        fprintf(outf, "%ld bytes allocated\n", endbrk - startbrk);
        getrusage(RUSAGE_SELF, &ourusage);
        
        delta = (endtime.tv_sec - starttime.tv_sec)
                + (endtime.tv_usec - starttime.tv_usec)/1000000.0;
        fprintf(outf, "elapsed %.3f ", delta);
        fprintf(outf, "utime %d.%03d stime %d.%03d\n",
                        ourusage.ru_utime.tv_sec,
                        ourusage.ru_utime.tv_usec/1000,
                        ourusage.ru_stime.tv_sec,
                        ourusage.ru_stime.tv_usec/1000);
        fprintf(outf, "maxrss %ld idrss %ld\n",
                        ourusage.ru_maxrss, ourusage.ru_idrss);
        fprintf(outf, "minflt %d majflt %d inblock %d oublock %d\n",
                        ourusage.ru_minflt , ourusage.ru_majflt ,
                        ourusage.ru_inblock , ourusage.ru_oublock);
                        
}

/*
 * Return current time, as a 64-bit unsigned scalar value in microseconds
 */
ulong64
now_usecs()
{
	struct timeval tv;
	
	gettimeofday(&tv, NULL);
	
	return(tv_to_usec(tv));
}
