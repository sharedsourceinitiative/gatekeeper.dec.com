/*
 * globals.h
 *
 * Part of: fatime program;
 * Measure file access times, for various phases of accessing a file,
 * across a set of files.
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: globals.h,v $
 * Revision 1.8  2002/01/31  22:31:51  mogul
 * Added -n flag
 *
 * Revision 1.7  2002/01/31  22:23:34  mogul
 * Support for -t flag
 *
 * Revision 1.6  2002/01/26  00:07:13  mogul
 * type consistency
 *
 * Revision 1.5  2002/01/10  19:34:21  mogul
 * Added assumedmeanhttpsize
 *
 * Revision 1.4  2001/12/11  02:02:21  mogul
 * Added Copyright notice.
 *
 * Revision 1.3  2001/12/11  01:59:45  mogul
 * Changed portability structure
 * Added Results_Update()
 *
 * Revision 1.2  2001/12/04  01:17:04  mogul
 * Checkpoint.
 *
 * Revision 1.1  2001/12/04  00:31:13  mogul
 * Initial revision
 *
 *
 *
 */

#include "portability.h"

extern int debug;
extern int debugDir;
extern int verbose;
extern int execstats;
extern int allperrors;
extern int namesonly;

extern int assumedmeanhttpsize;
extern int interimcount;

extern int filecount_all;
extern int filecount_reg;
extern int filecount_dir;
extern int filecount_special;
extern int open_failed;
extern int firstread_failed;
extern int lastread_failed;

/* Implementations in fatime.c */
ulong64 now_usecs();
void DoOutputs();

/* Implementations in dofiledir.c */
int DoFileOrDir(char *fordname);
void PrintCounters(FILE *outf);

/* Implementations in results.c */
void Results_InitDistribs();
void Results_PrintAllDistribs(FILE *outf, CumType cumulative);
void Results_Update(	int	is_nfs,
		ulong64	stat_delta,
		ulong64	open_delta,
		ulong64	firstread_delta,
		ulong64	restoffile_delta,
		ulong64	stattolast_delta,
		int	nblocks,
		off_t	nbytes);

/* Miscellaneous macros */
#define	tv_to_usec(tval)	(((tval).tv_sec * (long64)1000000) + (tval).tv_usec)
