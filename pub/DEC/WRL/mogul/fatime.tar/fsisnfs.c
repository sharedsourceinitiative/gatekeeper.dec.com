/*
 * fsisnfs.c
 *
 * Semi-portable code to decide if an open file is on an NFS-mounted
 * remote file system or not.
 *
 * Tested on:
 *	Linux
 *	Tru64
 *
 * Jeffrey Mogul
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * $Log: fsisnfs.c,v $
 * Revision 1.3  2002/01/26  00:07:07  mogul
 * *BSD support
 *
 * Revision 1.2  2001/12/11  18:59:53  mogul
 * Added copyright.
 *
 * Revision 1.1  2001/12/11  01:58:51  mogul
 * Initial revision
 *
 */

#include <sys/param.h>
#include <sys/mount.h>

#ifdef	linux
#include <sys/vfs.h>
/*
 * All of this kruft appears to be necessary simply in order to get
 * the definition of NFS_SUPER_MAGIC without instead having to drag
 * in half of the kernel.
 */
#include "linuxkludge.h"
#endif

#ifdef	TESTMAIN
main(int argc, char **argv)
{
	printf("stdin is NFS-mounted = %d\n", FSisNFS(0));
}
#endif

/*
 * Returns:
 *	0	fd is not NFS-mounted
 *	1	fd is NFS-mounted
 *	-1	error
 */
int
FSisNFS(int fd)
{
	struct statfs sfsb;
	int res;

	res = fstatfs(fd, &sfsb);
	if (res < 0) {
	    return(res);
	}
	
#ifdef	linux
	if (sfsb.f_type == NFS_SUPER_MAGIC) {
	    return(1);
	}
#endif

#ifndef	MFSNAMELEN
#ifdef	MOUNT_NFS
	if (sfsb.f_type == MOUNT_NFS) {
	    return(1);
	}
#endif
#ifdef	MOUNT_NFS3
	if (sfsb.f_type == MOUNT_NFS3) {
	    return(1);
	}
#endif
#endif

#ifdef	MFSNAMELEN
	/* OpenBSD or FreeBSD or NetBSD */
	if (strncmp(sfsb.f_fstypename, "nfs", 3) == 0) {
	    return(1);
	}
#endif

	return(0);
}
