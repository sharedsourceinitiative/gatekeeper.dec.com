/*
 * results.c
 *
 * Format & output results
 *
 * Part of: fatime program;
 * Measure file access times, for various phases of accessing a file,
 * across a set of files.
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: results.c,v $
 * Revision 1.8  2002/01/14  21:35:19  mogul
 * Changed argument types for Results_PrintAllDistribs
 *
 * Revision 1.7  2002/01/10  19:33:54  mogul
 * Added a bunch of distribs.
 *
 * Revision 1.6  2001/12/11  18:59:53  mogul
 * Added copyright.
 *
 * Revision 1.5  2001/12/11  01:59:09  mogul
 * Added conditional distributions.
 *
 * Revision 1.4  2001/12/11  00:49:50  mogul
 * Added NFS/Local breakdowns
 * Added bytes, blocks per file distributions.
 *
 * Revision 1.3  2001/12/10  19:45:15  mogul
 * Added first few graph types.
 *
 * Revision 1.2  2001/12/07  00:48:42  mogul
 * Added (arglist for) Results_Update
 *
 * Revision 1.1  2001/12/04  00:31:13  mogul
 * Initial revision
 *
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <sys/resource.h>

#include "portability.h"
#include "graphutil.h"
#include "globals.h"
#include "distrib.h"

/* A list of all distributions */
distrib_descrip distribs[] = {
#define	USECS_STAT_ALL 0
    {"uSec per stat() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_STAT_ALL},
#define	USECS_OPEN_ALL 1
    {"uSec per open() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_OPEN_ALL},
#define	USECS_FIRSTREAD_ALL 2
    {"uSec for first read() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_FIRSTREAD_ALL},
#define	USECS_REST_ALL 3
    {"uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_ALL},
#define	USECS_FULL_ALL 4
    {"uSec for open-to-close",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_FULL_ALL},
#define	USECS_STAT_NFS 5
    {"NFS uSec per stat() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_STAT_NFS},
#define	USECS_OPEN_NFS 6
    {"NFS uSec per open() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_OPEN_NFS},
#define	USECS_FIRSTREAD_NFS 7
    {"NFS uSec for first read() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_FIRSTREAD_NFS},
#define	USECS_REST_NFS 8
    {"NFS uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_NFS},
#define	USECS_FULL_NFS 9
    {"NFS uSec for open-to-close",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_FULL_NFS},
#define	USECS_STAT_LOCAL 10
    {"Local uSec per stat() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_STAT_LOCAL},
#define	USECS_OPEN_LOCAL 11
    {"Local uSec per open() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_OPEN_LOCAL},
#define	USECS_FIRSTREAD_LOCAL 12
    {"Local uSec for first read() call",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_FIRSTREAD_LOCAL},
#define	USECS_REST_LOCAL 13
    {"Local uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_LOCAL},
#define	USECS_FULL_LOCAL 14
    {"Local uSec for open-to-close",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_FULL_LOCAL},
#define	BYTES_ALL 15
    {"Bytes per file",
	NULL, DD_LOGBOTH, DD_CONT, 0, BYTES_ALL},
#define	BYTES_NFS 16
    {"NFS Bytes per file",
	NULL, DD_LOGBOTH, DD_CONT, 0, BYTES_NFS},
#define	BYTES_LOCAL 17
    {"Local Bytes per file",
	NULL, DD_LOGBOTH, DD_LAST, 0, BYTES_LOCAL},
#define	BLOCKS_ALL 18
    {"Blocks per file",
	NULL, DD_LOGBOTH, DD_CONT, 0, BLOCKS_ALL},
#define	BLOCKS_NFS 19
    {"NFS Blocks per file",
	NULL, DD_LOGBOTH, DD_CONT, 0, BLOCKS_NFS},
#define	BLOCKS_LOCAL 20
    {"Local Blocks per file",
	NULL, DD_LOGBOTH, DD_LAST, 0, BLOCKS_LOCAL},
#define	USECS_REST_ORLT1 21
    {"O FR lt 1 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_ORLT1},
#define	USECS_REST_OR1TO10 22
    {"O FR 1 to 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_OR1TO10},
#define	USECS_REST_ORGT10 23
    {"O FR gt 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_REST_ORGT10},
#define	USECS_REST_FRLT1 24
    {"FR lt 1 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_FRLT1},
#define	USECS_REST_FR1TO10 25
    {"FR 1 to 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_FR1TO10},
#define	USECS_REST_FRGT10 26
    {"FR gt 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_REST_FRGT10},
#define	USECS_REST_LT1MEAN 27
    {"size lt 1 mean for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_LT1MEAN},
#define	USECS_REST_1TO2MEAN 28
    {"size 1 to 2 mean for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_1TO2MEAN},
#define	USECS_REST_2TO10MEAN 29
    {"size 2 to 10 mean for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_2TO10MEAN},
#define	USECS_REST_GT10MEAN 30
    {"size gt 10 mean for other read() calls",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_REST_GT10MEAN},
#define	USECS_REST_SORLT1 31
    {"SO FR lt 1 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_SORLT1},
#define	USECS_REST_SOR1TO10 32
    {"SO FR 1 to 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_CONT, 0, USECS_REST_SOR1TO10},
#define	USECS_REST_SORGT10 33
    {"SO FR gt 10 msec uSec for other read() calls",
	NULL, DD_LOGBOTH, DD_LAST, 0, USECS_REST_SORGT10},
};

int numdistribs = sizeof(distribs)/sizeof(distrib_descrip);

void
Results_InitDistribs()
{
	GUtil_InitDistribs(distribs, numdistribs);
}

void
Results_PrintAllDistribs(FILE *outf, CumType cumulative)
{
	fprintf(outf, "## assumedmeanhttpsize %d\n", assumedmeanhttpsize);
	GUtil_PrintAllDistribs(outf, cumulative);
}

void
Results_Update(	int	is_nfs,
		ulong64	stat_delta,
		ulong64	open_delta,
		ulong64	firstread_delta,
		ulong64	restoffile_delta,
		ulong64	stattolast_delta,
		int	nblocks,
		off_t	nbytes)
{
	ulong64 o_and_fr;
	ulong64 so_and_fr;

	if (debug) {
	    fprintf(stderr,
	 "is_nfs %d blks %d B %d stat %d open %d 1strd %d rest %d full %d\n",
	 	is_nfs, nblocks, nbytes,
		stat_delta,
		open_delta,
		firstread_delta,
		restoffile_delta,
		stattolast_delta);
	}
	
	GUtil_BumpDistrib(USECS_STAT_ALL, stat_delta);
	GUtil_BumpDistrib(USECS_OPEN_ALL, open_delta);
	GUtil_BumpDistrib(USECS_FIRSTREAD_ALL, firstread_delta);
	GUtil_BumpDistrib(USECS_REST_ALL, restoffile_delta);
	GUtil_BumpDistrib(USECS_FULL_ALL, stattolast_delta);

	GUtil_BumpDistrib(BYTES_ALL, nbytes);	
	GUtil_BumpDistrib(BLOCKS_ALL, nblocks);	

	if (is_nfs) {
	    GUtil_BumpDistrib(USECS_STAT_NFS, stat_delta);
	    GUtil_BumpDistrib(USECS_OPEN_NFS, open_delta);
	    GUtil_BumpDistrib(USECS_FIRSTREAD_NFS, firstread_delta);
	    GUtil_BumpDistrib(USECS_REST_NFS, restoffile_delta);
	    GUtil_BumpDistrib(USECS_FULL_NFS, stattolast_delta);

	    GUtil_BumpDistrib(BYTES_NFS, nbytes);
	    GUtil_BumpDistrib(BLOCKS_NFS, nblocks);
	}
	else {
	    GUtil_BumpDistrib(USECS_STAT_LOCAL, stat_delta);
	    GUtil_BumpDistrib(USECS_OPEN_LOCAL, open_delta);
	    GUtil_BumpDistrib(USECS_FIRSTREAD_LOCAL, firstread_delta);
	    GUtil_BumpDistrib(USECS_REST_LOCAL, restoffile_delta);
	    GUtil_BumpDistrib(USECS_FULL_LOCAL, stattolast_delta);

	    GUtil_BumpDistrib(BYTES_LOCAL, nbytes);
	    GUtil_BumpDistrib(BLOCKS_LOCAL, nblocks);
	}

	/*
	 * Conditional distributions for restoffile_delta
	 * based on time for open+firstread, open+stat+firstread,
	 * or just firstread
	 */
	o_and_fr = open_delta + firstread_delta;
	if (o_and_fr < 1000) {
	    GUtil_BumpDistrib(USECS_REST_ORLT1, restoffile_delta);
	}
	else if (o_and_fr < 10000) {
	    GUtil_BumpDistrib(USECS_REST_OR1TO10, restoffile_delta);
	}
	else {
	    GUtil_BumpDistrib(USECS_REST_ORGT10, restoffile_delta);
	}

	so_and_fr = stat_delta + open_delta + firstread_delta;
	if (so_and_fr < 1000) {
	    GUtil_BumpDistrib(USECS_REST_SORLT1, restoffile_delta);
	}
	else if (so_and_fr < 10000) {
	    GUtil_BumpDistrib(USECS_REST_SOR1TO10, restoffile_delta);
	}
	else {
	    GUtil_BumpDistrib(USECS_REST_SORGT10, restoffile_delta);
	}

	if (firstread_delta < 1000) {
	    GUtil_BumpDistrib(USECS_REST_FRLT1, restoffile_delta);
	}
	else if (firstread_delta < 10000) {
	    GUtil_BumpDistrib(USECS_REST_FR1TO10, restoffile_delta);
	}
	else {
	    GUtil_BumpDistrib(USECS_REST_FRGT10, restoffile_delta);
	}

	/*
	 * Conditional distributions for restoffile_delta
	 * based on size bands as multiples of assumedmeanhttpsize.
	 */
	if (nbytes < assumedmeanhttpsize) {
	    GUtil_BumpDistrib(USECS_REST_LT1MEAN, restoffile_delta);
	}
	else if (nbytes < (2 * assumedmeanhttpsize)) {
	    GUtil_BumpDistrib(USECS_REST_1TO2MEAN, restoffile_delta);
	}
	else if (nbytes < (10 * assumedmeanhttpsize)) {
	    GUtil_BumpDistrib(USECS_REST_2TO10MEAN, restoffile_delta);
	}
	else {
	    GUtil_BumpDistrib(USECS_REST_GT10MEAN, restoffile_delta);
	}
}
