/*
 * lindistrib.c
 *
 * Functions for manipulating linear distributions
 *
 * Jeffrey Mogul
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: lindistrib.c,v $
 * Revision 1.10  2002/01/16  01:04:07  mogul
 * Added UpdateLinDistribTruncBW()
 *
 * Revision 1.9  2002/01/15  23:16:04  mogul
 * Portability to FreeBSD (thanks to Alec Wolman)
 *
 * Revision 1.8  2001/12/28  22:59:37  mogul
 * Support for PctCumDistrib printing.
 *
 * Revision 1.7  2001/12/12  00:56:44  mogul
 * Added computation of medians
 *
 * Revision 1.6  2001/12/11  01:57:40  mogul
 * Added copyright notice
 *
 * Revision 1.5  2001/12/01  01:51:42  mogul
 * Added ConfigureLinDistrib, UpdateLinDistribTrunc
 *
 * Revision 1.4  2001/12/01  01:03:27  mogul
 * Bug fix.
 *
 * Revision 1.3  2001/11/20  22:46:52  mogul
 * *** empty log message ***
 *
 * Revision 1.2  2001/08/24  21:16:47  mogul
 * Correct printf format
 *
 * Revision 1.1  2001/08/22  19:45:45  mogul
 * Initial revision
 *
 */

#include <stdio.h>
#include <math.h>
#include "portability.h"
/*#include <ctype.h> */
#include "distrib.h"

static int maxlindistidx = 1024;  /* XXX shouldn't be a global constant! */

void ConfigureLinDistrib(int maxindex)
{
	maxlindistidx = maxindex;
}

long *InitLinDistrib()
{
	long *distrib;
	int allocbytes;
	
	allocbytes = sizeof(long) * (maxlindistidx + 1);
	distrib = (long *)malloc(allocbytes);
	if (distrib == NULL) {
	    perror("InitLinDistrib");
	    exit(1);
	}
	bzero(distrib, allocbytes);
	return(distrib);
}

void UpdateLinDistrib(long *distrib, int xval)
{
	int idx;
	
	idx = xval;

	/* avoid negative index values */
	if (idx < 0)
	    idx = 0;
	if (idx > maxlindistidx)
	    idx = maxlindistidx;

	distrib[idx]++;
}

/* Same as UpdateLinDistrib, but discards out-of-range values */
void UpdateLinDistribTrunc(long *distrib, int xval, int truncval)
{
	int idx;
	
	idx = xval;

	/* discard out-of-range values */
	if ((idx < 0) || (idx > maxlindistidx))
	    return;
	if (idx > truncval)
	    return;

	distrib[idx]++;
}

/* byte-weighted distribution */
void UpdateLinDistribBW(long *distrib, int xval, int len)
{
	int idx;

	idx = xval;

	/* avoid negative index values */
	if (idx < 0)
	    idx = 0;
	if (idx > maxlindistidx)
	    idx = maxlindistidx;

	distrib[idx] += len;
}

/* Same as UpdateLinDistribBW, but discards out-of-range values */
void
UpdateLinDistribTruncBW(long *distrib, int xval, int truncval, int len)
{
	int idx;
	
	idx = xval;

	/* discard out-of-range values */
	if ((idx < 0) || (idx > maxlindistidx))
	    return;
	if (idx > truncval)
	    return;

	distrib[idx] += len;
}

void PrintLinDistrib(FILE *outf, long *distrib)
{
	int i;

	for (i = 0; i <= maxlindistidx; i++) {
	    if (distrib[i]) {
		fprintf(outf, "%d %ld\n", i, distrib[i]);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void PrintLinCumDistrib(FILE *outf, long *distrib)
{
	int i;
	long sum;

	sum = 0;
	for (i = 0; i <= maxlindistidx; i++) {
	    if (distrib[i]) {
		sum += distrib[i];
		fprintf(outf, "%d %ld\n", i, sum);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void PrintLinPctCumDistrib(FILE *outf, long *distrib)
{
	int i;
	long sum;
	long total;

	total = 0;
	for (i = 0; i <= maxlindistidx; i++) {
	    total += distrib[i];
	}

	sum = 0;
	for (i = 0; i <= maxlindistidx; i++) {
	    if (distrib[i]) {
		sum += distrib[i];
		fprintf(outf, "%d %f\n", i, (sum * 100.0)/total);
	    }
	}
/*	fprintf(outf, "break\n\n"); */
}

void
BBoxLinDistrib(long *distrib,
	long *xminp, long *xmaxp, long *yminp, long *ymaxp,
	long *firstp, long *totp)
{
	long xmax, xmin, ymax, ymin;
	long tot;
	int i;
	long v;
	int firstset = 0;
	
	xmax = -1;
	xmin = MAXLONG;
	ymax = -1;
	ymin = MAXLONG;
	tot = 0;
	
	for (i = 0; i <= maxlindistidx; i++) {
	    v = distrib[i];
	    tot += v;
	    if (v) {
		if (firstset == 0) {
		    *firstp = tot;
		    firstset = 1;
		}
		if (i < xmin)
		    xmin = i;
		if (i > xmax)
		    xmax = i;
		if (v < ymin)
		    ymin = v;
		if (v > ymax)
		    ymax = v;
	    }
	}
	
	*xminp = xmin;
	*xmaxp = xmax;
	*yminp = ymin;
	*ymaxp = ymax;
	*totp = tot;
}

/*
 * Compute median of distribution.  Uses brute-force approach
 * Assumptions:
 *	number of samples fits into an unsigned long
 */
long
LinDistribMedian(long *distrib)
{
	unsigned long tot;
	unsigned long sum;
	int i;
	long v;
	
	/*
	 * Step 1: find out how many samples we have
	 */
	tot = 0;
	for (i = 0; i <= maxlindistidx; i++) {
	    tot += distrib[i];
	}
	
	/*
	 * Step 2: count samples again, until we've found half of them
	 */
	sum = 0;
	for (i = 0; i <= maxlindistidx; i++) {
	    sum += distrib[i];
	    if (sum >= (tot/2))
		return(i);
	}
	
	fprintf(stderr, "LinDistribMedian: should't happen\n");
	abort();
}
