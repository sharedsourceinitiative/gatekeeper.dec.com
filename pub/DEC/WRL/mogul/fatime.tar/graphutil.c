/*
 * graphutil.c
 *
 * HTTP Out-of-order processing simulation:
 * utility functions for graph-plotting
 *
 * We assume we're creating input for psgraph:
 *	http://gatekeeper.dec.com/pub/DEC/psgraph.tar.Z
 *
 */

/*
 *    Copyright (c) 2001 Compaq Computer Corporation
 *
 *    SOFTWARE RELEASE
 *    
 *    Permission is hereby granted, free of charge, to any person obtaining a
 *    copy of this software and associated documentation files (the
 *    "Software"), to deal in the Software without restriction, including
 *    without limitation the rights to use, copy, modify, merge, publish,
 *    distribute, sublicense, and/or sell copies of the Software, and to
 *    permit persons to whom the Software is furnished to do so, subject to
 *    the following conditions:
 *
 *	Redistributions of source code must retain the above copyright
 *	notice, this list of conditions and the following disclaimer.
 *
 *	Redistributions in binary form must reproduce the above
 *	copyright notice, this list of conditions and the following
 *	disclaimer in the documentation and/or other materials provided
 *	with the distribution.
 *
 *	Except as contained in this notice, the name of COMPAQ Computer
 *	Corporation shall not be used in advertising or otherwise to
 *	promote the sale, use or other dealings in this Software
 *	without prior written authorization from COMPAQ Computer
 *	Corporation.
 *    
 *    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 *    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *    IN NO EVENT SHALL COMPAQ COMPUTER CORPORATION BE LIABLE FOR ANY CLAIM,
 *    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 *    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
 *    THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/*
 * History:
 * $Log: graphutil.c,v $
 * Revision 1.20  2002/01/16  23:13:39  mogul
 * Supports OpenBSD/FreeBSD style of printf("%lld") for long long ints
 *
 * Revision 1.19  2002/01/16  01:03:39  mogul
 * Added GUtil_BumpWeightedDistrib()
 *
 * Revision 1.18  2002/01/15  23:16:04  mogul
 * Portability to FreeBSD (thanks to Alec Wolman)
 *
 * Revision 1.17  2002/01/14  21:39:08  mogul
 * Don't try to print keys for empty graphs.
 * Added ## STATSLABEL comments
 *
 * Revision 1.16  2002/01/09  00:27:55  mogul
 * Avoid taking log(0) when computing positions for graph keys.
 *
 * Revision 1.15  2002/01/08  22:00:45  mogul
 * Even if graph is empty, we may need to print key.
 *
 * Revision 1.14  2001/12/28  23:14:33  mogul
 * Sanity check for too many keys
 * Make sort order the same on Linux, by brute force
 *
 * Revision 1.13  2001/12/28  22:58:25  mogul
 * Supports PctCDF
 *
 * Revision 1.12  2001/12/28  22:56:36  mogul
 * Checkpoint (with debugging stuff)
 *
 * Revision 1.11  2001/12/28  21:59:07  mogul
 * Cleaned up printing of graph keys
 *
 * Revision 1.10  2001/12/27  22:45:32  mogul
 * Added DD_LOGX
 *
 * Revision 1.9  2001/12/27  19:00:12  mogul
 * Changed the name of a variable
 * Added some line types
 *
 * Revision 1.8  2001/12/13  21:47:27  mogul
 * Get the types right (to avoid overflow)
 *
 * Revision 1.7  2001/12/12  21:07:08  mogul
 * removed temporary debugging code.
 *
 * Revision 1.6  2001/12/12  21:06:00  mogul
 * improved portability to 32-bit systems
 *
 * Revision 1.5  2001/12/12  00:56:44  mogul
 * Added computation of medians
 *
 * Revision 1.4  2001/12/12  00:06:44  mogul
 * No /0 when n = 1
 *
 * Revision 1.3  2001/12/11  01:57:40  mogul
 * Added copyright notice
 *
 * Revision 1.2  2001/12/11  01:45:36  mogul
 * Minor bug-fixes
 *
 * Revision 1.1  2001/12/07  01:20:36  mogul
 * Initial revision
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include "portability.h"
#include "graphutil.h"
#include "distrib.h"

static int max_lin_index = 10000;	/* XXX Hack */

static int numdists;

static distrib_descrip *distribarray;

static int bumptruncs = 0;

/* Internally-used type to temporarily record info for a graph key */
typedef struct key_entry_t {
	char 	*description;
	int	linetype;
	ulong64	sortkey;
	int	xlim;
} key_entry;

#define	MAXKEYS	64	/* More than any sane graph could show */
static key_entry key_entries[MAXKEYS];

void GUtil_InitDistribs(distrib_descrip *distribs, int ndistrib)
{
	int i;
	distrib_descrip *ddp;
	
	distribarray = distribs;
	numdists = ndistrib;
	
	ConfigureLinDistrib(max_lin_index);

	for (i = 0; i < numdists; i++) {
	    ddp = &(distribarray[i]);
	
	    /* Consistency check */
	    if (ddp->index != i) {
		fprintf(stderr, "distribarray[%d].index = %d\n",
			i, ddp->index);
		exit(1);
	    }
	    
	    if ((ddp->is_log == DD_LOGBOTH) || (ddp->is_log == DD_LOGX))
	    	ddp->distrib_data = InitLogDistrib();
	    else
	    	ddp->distrib_data = InitLinDistrib();

	    /* Probably not necessary */
	    ddp->stats.n = 0;
	    ddp->stats.sum_x = 0;
	    ddp->stats.sum_x_squared = 0;
	}
}

void
GUtil_PrintGraphHeader(FILE *outf, int is_log, const char *distname,
		CumType cumulative, int xlim)
{
	const char *cp;
	char c;
	
	/*
	 * Tag the graph with a name suitable for use as a filename.
	 * Use distribution name, skipping spaces and stopping at
	 * a non-alphanumeric.
	 */
	fprintf(outf, "## SIMPLENAME ");
	cp = distname;
	while (c = *cp++) {
	    if (isspace(c))
		continue;
	    if (isalnum(c))
		fputc(c, outf);
	    else
		break;
	}
	fprintf(outf, "\n");

	fprintf(outf, "grid 5\n");
	fprintf(outf, "x size 5\n");
	fprintf(outf, "y size 3\n");
	fprintf(outf, "transparent\n");
	fprintf(outf, "spline\n");

	switch (cumulative) {
	case CDF:
	    fprintf(outf, "y label \"Cumulative count\"\n");
	    break;
	case PctCDF:
	    fprintf(outf, "y label \"Cumulative %%\"\n");
	    fprintf(outf, "y max 100\n");
	    break;
	case PDF:
	    fprintf(outf, "y label \"Count\"\n");
	    break;
	}

	if (xlim > 0)
	    fprintf(outf, "x max %d\n", xlim);

	if (is_log == DD_LOGBOTH) {
	    fprintf(outf, "x log\n");
	    fprintf(outf, "y log\n");
	    fprintf(outf, "x intervals 10\n");
	    fprintf(outf, "y intervals 10\n");
	}
	else if (is_log == DD_LOGY) {
	    fprintf(outf, "y log\n");
	    fprintf(outf, "y intervals 10\n");
	}
	else if (is_log == DD_LOGX) {
	    fprintf(outf, "x log\n");
	    fprintf(outf, "x intervals 10\n");
	}
	else {
	    /* anything? */
	}

	fprintf(outf, "\n");
}

char *linetypes[] = {
	"color red\nline solid\n",
	"color blue\nline dotted\n",
	"color magenta\nline longdashed\n",
	"color green\nline shortdashed\n",
	"color violet\nline dotdashed\n",
	"color orange\nline dotted\n",
	"color black\nline solid\n",
};

void GUtil_PrintGraphLineType(FILE *outf, int linetype)
{
	if ((linetype < 0) || (linetype >= sizeof(linetypes)/sizeof(char *))) {
	    /* XXX or should this be done mod num of linetypes? */
	    fprintf(stderr, "linetype %d too large\n", linetype);
	    exit(1);
	}
	
	fprintf(outf, "%s", linetypes[linetype]);
}

void GUtil_PrintGraphBreak(FILE *outf)
{
	fprintf(outf, "break\n");
	fprintf(outf, "\n\n");
	fprintf(outf, "## SIMPLEEND\n");
}

void
GUtil_PrintLogKey(FILE *outf, long *d_data, char *d_name, int offset,
			int xlim)
{
	long xmax, xmin, ymax, ymin, first, tot;
	float ypos;
	float xpos;
	
	fprintf(outf, "break\n");

	BBoxLogDistrib(d_data, &xmin, &xmax, &ymin, &ymax, &first, &tot);
	
	if (offset) {
	    /* Set y position progressively higher for each higher offset */
	    ypos = tot;
	    ypos = ypos - (ypos/(offset + 2));
	}
	else {
	    ypos = ymax;
	}
	
	/* Start the line one decade from left edge */
	xpos = xmin * 10.0;
	
	fprintf(outf, "%f %f\n", xpos, ypos);

	/* End the line two decades from left edge */
	xpos = xmin * 100.0;
	fprintf(outf, "%f %f \"%s\"\n", xpos, ypos, d_name);

	fprintf(outf, "break\n");
}

void
GUtil_PrintLinKey(FILE *outf, long *d_data, char *d_name, int offset,
			int xlim)
{
	long xmax, xmin, ymax, ymin, first, tot;
	float ypos;
	float xpos;
	
	fprintf(outf, "break\n");

	BBoxLinDistrib(d_data, &xmin, &xmax, &ymin, &ymax, &first, &tot);
	
	if (offset) {
	    /* Set y position progressively higher for each higher offset */
	    ypos = tot;
	    ypos = ypos - (ypos/(offset + 2));
	}
	else {
	    ypos = ymax;
	}
	
	/* Start the line 5% from left edge */
	if (xmax > xlim)
	    xmax = xlim;
	xpos = xmin + ((xmax - xmin)*0.05);
	
	fprintf(outf, "%f %f\n", xpos, ypos);

	/* End the line 10% from left edge */
	xpos = xmin + ((xmax - xmin)*0.10);
	fprintf(outf, "%f %f \"%s\"\n", xpos, ypos, d_name);

	fprintf(outf, "break\n");
}

/* Sort functions for key_entry values */
int
GUtil_CmpGraphKeysIncreasing(const void *v1p, const void *v2p)
{
        key_entry *ke1p = (key_entry *)v1p;
        key_entry *ke2p = (key_entry *)v2p;

	if (ke1p->sortkey > ke2p->sortkey)
	    return(1);
	if (ke1p->sortkey < ke2p->sortkey)
	    return(-1);
	/* linetypes should be unique (?); makes this sort same on Linux */
	return(ke1p->linetype - ke2p->linetype);
}

int
GUtil_CmpGraphKeysDecreasing(const void *v1p, const void *v2p)
{
        key_entry *ke1p = (key_entry *)v1p;
        key_entry *ke2p = (key_entry *)v2p;

	if (ke2p->sortkey > ke1p->sortkey)
	    return(1);
	if (ke2p->sortkey < ke1p->sortkey)
	    return(-1);
	/* linetypes should be unique (?); makes this sort same on Linux */
	return(ke2p->linetype - ke1p->linetype);
}

/*
 * Prints all of the keys for a graph:
 *	CDF: in lower right corner
 *	PDF: in upper right corner
 * XXX perhaps this choice should be explicit in distrib_descrip?
 * XXX is "tot" param useful?
 */
static void
GUtil_PrintGraphKeys(FILE *outf, int numkeys, CumType cumulative, int is_log,
	long xmin, long xmax, long ymin, long ymax, long tot)
{
	key_entry *kep;
	int i;
	int temp;
	float yoff, ydelta;
	float xleft, xright;
	int y_islog, x_islog;
	float yminf = ymin;
	float ymaxf = ymax;
	float xminf = xmin;
	float xmaxf = xmax;

	switch (is_log) {
	case DD_LIN:
	    x_islog = 0;
	    y_islog = 0;
	    break;
	case DD_LOGBOTH:
	    x_islog = 1;
	    y_islog = 1;
	    break;
	case DD_LOGX:
	    x_islog = 1;
	    y_islog = 0;
	    break;
	case DD_LOGY:
	    x_islog = 0;
	    y_islog = 1;
	    break;
	}
	
	/* avoid taking log(0) */
	if (y_islog && (ymin < 1))
	    ymin = 1;

	if (x_islog && (xmin < 1))
	    xmin = 1;

	yminf = ymin;
	ymaxf = ymax;
	xminf = xmin;
	xmaxf = xmax;

	if (y_islog) {
	    /* psgraph sets y bounds at powers of ten */
	    temp = log10f(ymaxf) + 1;
	    ymaxf = powf(10.0, temp + 0.0);
	    temp = log10f(yminf);
	    yminf = powf(10.0, temp + 0.0);
	}

	if (cumulative == PctCDF) {
	    ymaxf = 100.0;
	}

	/*
	 * Compute initial and incremental y offset
	 *	we start from the top and work down!
	 */
	switch (cumulative) {
	case CDF:
	case PctCDF:
	    if (y_islog) {
		yoff = (log10f(ymaxf) + log10f(yminf))/2.0;
		yoff = powf(10.0, yoff + 0.0);
	    }
	    else {
		yoff = (ymaxf + yminf)/2.0;
	    }
	    break;
	case PDF:
	    yoff = ymax + 0.0;
	    break;
	}

	if (y_islog) {
	    ydelta = (log10f(ymaxf) - log10f(yminf))/(2.0 * numkeys);
	    ydelta = powf(10.0, ydelta);
	}
	else {
	    ydelta = (ymaxf - yminf)/(2.0 * numkeys);
	}
	
	/* Compute xleft and xright - spaced about 10% of graph width */
	if (x_islog) {
	    xleft = (log10f(xmaxf) + log10f(xminf))/2.0;
	    xright = xleft * 1.20;
	    xleft = powf(10.0, xleft);
	    xright = powf(10.0, xright);
	}
	else {
	    xleft = (xmaxf + xminf)/2.0;
	    xright = xleft * 1.20;
	}

	for (i = 0; i < numkeys; i++) {
	    kep = &(key_entries[i]);
	    
	    GUtil_PrintGraphLineType(outf, kep->linetype);

	    fprintf(outf, "%f %f\n", xleft, yoff);
	    fprintf(outf, "%f %f \"%s\"\n", xright, yoff, kep->description);

	    fprintf(outf, "break\n");
	    
	    if (y_islog) {
		yoff = yoff/ydelta;
	    }
	    else {
		yoff = yoff - ydelta;
	    }
	}
}

void
GUtil_Statistics(FILE *outf, distrib_descrip *ddp)
{
	double mean;
	double variance;
	double stddev;
	double n;
	double sum;
	double sumsquared;
	float fmedian;
	long imedian;
	
	n = ddp->stats.n;
	if (n < 1)	/* no div by zero! */
	    return;
	sum = ddp->stats.sum_x;
	sumsquared = ddp->stats.sum_x_squared;

        mean = sum/n;
	if (n > 1)
	    variance = (sumsquared - (sum * (sum/n))) / (n - 1);
	else
	    variance = 0;
        stddev = sqrt(variance);

	/* debugging output */
#ifdef	printf_L
	fprintf(outf,
		"#$ stats.n %ld stats.sum_x %Ld stats.sum_x_squared %e\n",
		ddp->stats.n, ddp->stats.sum_x, ddp->stats.sum_x_squared);
#elif	defined(printf_ll)
	fprintf(outf,
		"#$ stats.n %ld stats.sum_x %lld stats.sum_x_squared %e\n",
		ddp->stats.n, ddp->stats.sum_x, ddp->stats.sum_x_squared);
#else
	fprintf(outf,
		"#$ stats.n %ld stats.sum_x %ld stats.sum_x_squared %e\n",
		ddp->stats.n, ddp->stats.sum_x, ddp->stats.sum_x_squared);
#endif

	fprintf(outf, "## STATSLABEL %s\n", ddp->distrib_name);
	fprintf(outf, "## STATS: N %ld MEAN %f STDDEV %f ",
		ddp->stats.n, mean, stddev);

	if (ddp->is_log) {
	    fmedian = LogDistribMedian(ddp->distrib_data);
	    fprintf(outf, "MEDIAN %f\n", fmedian);
	}
	else {
	    imedian = LinDistribMedian(ddp->distrib_data);
	    fprintf(outf, "MEDIAN %d\n", imedian);
	}
}

void GUtil_PrintAllDistribs(FILE *outf, CumType cumulative)
{
	int i;
	distrib_descrip *ddp;
	int continued = 0;
	int linetype;
	int numkeys;
	long xmax, xmin, ymax, ymin, tot;
	long thisxmax, thisxmin, thisymax, thisymin, thisfirst, thistot;
	long thisfirstnorm;
	
	for (i = 0; i < numdists; i++) {
	    ddp = &(distribarray[i]);
	
	    if (continued == 0) {
		GUtil_PrintGraphHeader(outf, ddp->is_log,
					ddp->distrib_name, cumulative,
					ddp->xlim);
		linetype = 0;
		/*
		 * Instead of printing the key for each curve as we
		 * construct the graph, we collect the key information
		 * and bounding box as we go through the curves, then emit
		 * all of the keys once we know the general shape of the 
		 * graph.
		 */ 
		xmax = 0;
		xmin = MAXLONG;
		ymax = 0;
		ymin = MAXLONG;
		tot = 0;
		numkeys = 0;
	    }
	    else {
		linetype++;
	    }

	    continued = ddp->continues;
	    
	    if (ddp->stats.n == 0) {	/* don't print empty graphs */
		/* Even if graph is empty, we may need to print key */
		goto checkforkey;
	    }

	    fprintf(outf, "x label \"%s\"\n", ddp->distrib_name);
	    fprintf(outf, "# distrib index %d\n", i);

	    GUtil_PrintGraphLineType(outf, linetype);

	    if ((ddp->is_log == DD_LOGBOTH) || (ddp->is_log == DD_LOGX)) {
	        BBoxLogDistrib(ddp->distrib_data,
			&thisxmin, &thisxmax, &thisymin, &thisymax,
			&thisfirst, &thistot);
		switch (cumulative) {
		case CDF:
		    PrintLogCumDistrib(outf, ddp->distrib_data);
		    break;
		case PctCDF:
		    PrintLogPctCumDistrib(outf, ddp->distrib_data);
		    break;
		case PDF:
		    PrintLogDistrib(outf, ddp->distrib_data);
		    break;
		}
	    }
	    else {
	        BBoxLinDistrib(ddp->distrib_data,
			&thisxmin, &thisxmax, &thisymin, &thisymax,
			&thisfirst, &thistot);
		switch (cumulative) {
		case CDF:
		    PrintLinCumDistrib(outf, ddp->distrib_data);
		    break;
		case PctCDF:
		    PrintLinPctCumDistrib(outf, ddp->distrib_data);
		    break;
		case PDF:
		    PrintLinDistrib(outf, ddp->distrib_data);
		    break;
		}
	    }
	    
	    /* Update bounding box, record key info */
	    if (thisxmin < xmin)
		xmin = thisxmin;
	    if (thisxmax > xmax)
		xmax = thisxmax;
	    if ((ddp->xlim > 0) && (xmax > ddp->xlim))
		xmax = ddp->xlim;
	    switch (cumulative) {
	    case CDF:
		if (thisfirst < ymin)
		    ymin = thisfirst;
		if (thistot > ymax)
		    ymax = thistot;
		break;
	    case PctCDF:
		thisfirstnorm = (100 * thisfirst)/thistot;
		if (thisfirstnorm < ymin)
		    ymin = thisfirstnorm;
		ymax = 100;
		break;
	    case PDF:
		if (thisymin < ymin)
		    ymin = thisymin;
		if (thisymax > ymax)
		    ymax = thisymax;
		break;
	    }
	    tot += thistot;

	    key_entries[numkeys].description = ddp->distrib_name;
	    key_entries[numkeys].linetype = linetype;
	    key_entries[numkeys].sortkey = ddp->stats.sum_x/ddp->stats.n;
	    key_entries[numkeys].xlim = ddp->xlim;

	    numkeys++;
	    if (numkeys >= MAXKEYS) {
		fprintf(stderr, "GUtil_InitDistribs: more than %d keys\n",
			numkeys);
		abort();
	    }

	    GUtil_Statistics(outf, ddp);

	    GUtil_PrintGraphBreak(outf);
	    
checkforkey:
	    if ((continued == 0) && (numkeys > 0)) {
		/*
		 * Sort in *increasing* order of keys because if
		 * the mean is further right, the curve is generally
		 * lower (and GUtil_PrintGraphKeys works top-down).
		 */
		qsort(key_entries, numkeys, sizeof(key_entry),
					GUtil_CmpGraphKeysIncreasing);
		GUtil_PrintGraphKeys(outf, numkeys, cumulative, ddp->is_log,
					xmin, xmax, ymin, ymax, tot);
	    }
	}
	fprintf(outf, "# bumptruncs %d\n", bumptruncs);
}

void GUtil_BumpDistrib(int distrib_index, ulong64 dataval)
{
	distrib_descrip *ddp;
	double dv_sq;
	int dv;		/* same type as last arg of Update*Distrib() */
	ulong64 dvcheck;
	
	if ((distrib_index < 0) || (distrib_index >= numdists)) {
	    fprintf(stderr, "GUtil_BumpDistrib(%d, %ld): bad index\n",
			distrib_index, dataval);
	    exit(1);
	}
	ddp = &(distribarray[distrib_index]);

	/*
	 * Do this dance to avoid overflowing the width of
	 * the second argument to Update*Distrib()
	 */
	dv = dataval;
	dvcheck = dv;
	if (dvcheck != dataval) {	/* oops, conversion failed */
	    dv = MAXINT;
	    bumptruncs++;
	}

	if (ddp->is_log == DD_LOGBOTH)
	    UpdateLogDistrib(ddp->distrib_data, dv);
	else if (ddp->is_log == DD_LOGX)
	    UpdateLogDistrib(ddp->distrib_data, dv);
	else if (ddp->is_log == DD_LOGY)
	    UpdateLinDistribTrunc(ddp->distrib_data, dv,
					(max_lin_index - 1));
	else
	    UpdateLinDistrib(ddp->distrib_data, dv);

	ddp->stats.n++;
	ddp->stats.sum_x += dataval;
	dv_sq = (((double)(dataval + 0.0)) * ((double)(dataval + 0.0)));
	ddp->stats.sum_x_squared += dv_sq;
}

void
GUtil_BumpWeightedDistrib(int distrib_index, ulong64 dataval, ulong64 weight)
{
	distrib_descrip *ddp;
	double dv_sq;
	int dv;		/* same type as last arg of Update*Distrib() */
	ulong64 dvcheck;
	
	if ((distrib_index < 0) || (distrib_index >= numdists)) {
	    fprintf(stderr,
	    	"GUtil_BumpWeightedDistrib(%d, %ld, %ld): bad index\n",
			distrib_index, dataval, weight);
	    exit(1);
	}
	ddp = &(distribarray[distrib_index]);

	/*
	 * Do this dance to avoid overflowing the width of
	 * the second argument to Update*Distrib()
	 */
	dv = dataval;
	dvcheck = dv;
	if (dvcheck != dataval) {	/* oops, conversion failed */
	    dv = MAXINT;
	    bumptruncs++;
	}

	if (ddp->is_log == DD_LOGBOTH)
	    UpdateLogDistribBW(ddp->distrib_data, dv, weight);
	else if (ddp->is_log == DD_LOGX)
	    UpdateLogDistribBW(ddp->distrib_data, dv, weight);
	else if (ddp->is_log == DD_LOGY)
	    UpdateLinDistribTruncBW(ddp->distrib_data, dv, weight,
					(max_lin_index - 1));
	else
	    UpdateLinDistribBW(ddp->distrib_data, dv, weight);

	ddp->stats.n++;
	ddp->stats.sum_x += dataval;
	dv_sq = (((double)(dataval + 0.0)) * ((double)(dataval + 0.0)));
	ddp->stats.sum_x_squared += dv_sq;
}

/*
 * Compute the ratio (expressed as an integer percentage)
 * taking care not to divide by zero.
 */
int PctRatio(long64 vnew, long64 vorig)
{
	float fnew, forig, fratio;
	int result;

	if (vorig <= 0)
	    return(1000);	/* XXX or something else? */

	fnew = vnew;
	forig = vorig;
	fratio = (100.0*vnew)/vorig;
	result = fratio;
	return(result);
}
