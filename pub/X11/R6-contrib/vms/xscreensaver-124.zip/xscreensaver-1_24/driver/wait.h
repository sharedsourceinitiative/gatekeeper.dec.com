/* Null file works for VMS */
