static char *screensaver_id =
	"@(#)xscreensaver 1.26, by Jamie Zawinski (jwz@netscape.com)";
