/*
 *  alarm.h -- externs
 */
extern void InitBellAlarm();
extern void SetAlarm();
extern void SetBell();
extern void GetBellSize();
extern void AlarmOff();
extern void DrawBell();
