/* stubs, alas.... */

#define SND_CANTMOVE 0
