#define N_HELP 5

extern unsigned char credits_img_bits[];
extern unsigned char *help_img_bits[];

extern int credits_pix[];
extern int *help_pix[];

extern unsigned char *help_button_bits[];
