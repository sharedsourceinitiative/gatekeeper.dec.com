#include "blockade.h"

#ifndef N_DEF_LEVELS

#define N_DEF_LEVELS 80

struct def_level_ {
  char *name;
  char layout[BOARD_Y][BOARD_X];
  } ;
typedef struct def_level_ DEF_LEVEL;

extern DEF_LEVEL b_l_builtin[N_DEF_LEVELS];

#endif
