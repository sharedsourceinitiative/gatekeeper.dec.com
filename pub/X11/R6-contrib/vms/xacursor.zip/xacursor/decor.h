#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>


#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include <sys/time.h>
#include <sys/types.h>

#ifndef VMS
#include <unistd.h>
#else
#include "unix_time.h"
#endif /* VMS */

#define usleep					my_usleep


#define STR_LENGTH				1000
#define SEC						1000000


#define NUM_CURSOR				50
#define NUM_DEMO				15

#define SLEEP_TIME				200000





typedef struct
	{
	int		width,
			height,
	
			x,
			y;

	char	*bits;
	} demo_type;


typedef enum {Normal, Swing, Vibrate, Random, Random_Swing} mode_type;

typedef enum {Root_F, Cursor_F, Mask_F, Demo_F, File_F} flag_type;


