
/*
* xfile.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xfile.c
*
*
*/

/* File Menu Buttons */

#define NEW_BUT 0
#define OPEN_BUT 1
#define SAVE_BUT 2
#define SAVE_AS_BUT 3
#define INSERT_BUT 4
#define EXPORT_BUT 5
#define RELOAD_BUT 6
#define CCI_BUT 7
#define NET_BUT 8
#define PRINT_BUT 9
#define NEW_FRAME_BUT 10
#define CLOSE_FRAME_BUT 11
#define EXIT_BUT 12


#define GET 0
#define POST 1
#define NO_METHOD 2

#define PTEXT 0
#define FTEXT 1
#define POSTSCRIPT 2

#define TREGULAR 0
#define TSMALL 1
#define TLARGE 2
#define HREGULAR 3
#define HSMALL 4
#define HLARGE 5
#define NCREGULAR 6
#define NCSMALL 7
#define NCLARGE 8
#define LREGULAR 9
#define LSMALL 10
#define LLARGE 11

#define TIMES 0
#define HELVETICA 1
#define NEW_CENTURY 2
#define LUCIDA_BRIGHT 3

#define HTML_NEW 0
#define TEXT_NEW 1

/* Routines in xhtml.c file */
HTMLED *create_rest_widgets(Widget shell,HTMLED *);
void initialize_editor(HTMLED *);
void gain_focus(Widget w, XtPointer cld, XtPointer cd);
void Initialize_list(void);

/* Routines in xfile.c file */
int read_file(char *,HTMLED *he);
int save_file(char *,HTMLED *he);
int insert_file(char *,HTMLED *he);
void new_file(HTMLED *he);
void new_name(Widget w, XtPointer client_data, XtPointer call_data);
void simple_save_file(Widget w,HTMLED *he);
void warning_message(Widget w,HTMLED *he);
int save_file_ok(HTMLED *he);
void ok_pushed(Widget w, XtPointer client_data,XtPointer call_data);


void    help_done(Widget);

Widget CreateMenuBar(Widget parent,HTMLED *);
void PrintButtonCallBack(Widget,XtPointer, XtPointer);
void OkFileButtonCallback(Widget ,XtPointer, XtPointer);
void CancelFileButtonCallback(Widget , XtPointer , XtPointer);
void FileButtonCallBack(Widget , XtPointer , XtPointer);
void OkSaveButtonCallBack(Widget , XtPointer , XtPointer);
void SaveButtonCallBack(Widget , XtPointer , XtPointer);
void ClearButtonCallBack(Widget , XtPointer , XtPointer);
void InsertParagraph(Widget , XtPointer , XtPointer);
void InsertCode(Widget , XtPointer , XEvent *);
void CodeParagraphInserted(Widget , XmTextPosition );
void InsertTitle(Widget , XtPointer , XtPointer);
void OkTitleButton(Widget, XtPointer , XtPointer); 
void CancelTitleButton(Widget, XtPointer , XtPointer);
void HeaderButtonCallBack(Widget , XtPointer , XtPointer);
void OkHeaderButton(Widget, XtPointer , XtPointer); 
void CancelHeaderButton(Widget, XtPointer , XtPointer);
void SetMessageWindow(Widget ,char *);
char *GetTitleMessage(void);
void toggled(Widget, XtPointer , XtPointer); 
void file_cb( Widget ,int , XtPointer );
void Set_label(Widget w,char *label);
void cut_paste(Widget w, int item_no);
void Setmenu(Widget w,HTMLED *);
void printing(Widget w,XtPointer unused,XmSelectionBoxCallbackStruct *cbs);
void parsing_hightlight(char *text,XmTextPosition,int count,HTMLED *);
void Set_Underline_Tags(Widget w, XtPointer,XmToggleButtonCallbackStruct *);
void response(Widget widget, XtPointer client_data, XtPointer call_data);
int AskUser(Widget parent, char *question);
void Export_HTML(Widget  w,XtPointer client_data, XtPointer call_data);
void export_cb(Widget w, XtPointer client_data, XtPointer call_data);
void OkExportButtonCallback(Widget w, XtPointer , XtPointer );
void save_format_file(HTMLED *he);
void ok_format_file(Widget w, XtPointer client_data,XtPointer call_data);
void warning_format_file(Widget w,HTMLED *he);
void routines_fonts(Widget w, XtPointer client_data,XtPointer call_data);
long getFont (char *name,Widget whtml);
