#define MAX_LINE        81


unsigned char *ReadXpmPixmap(FILE *fp, char *datafile, int *w, int *h,
        XColor *colrs, int Colors, int CharsPP, Widget view);

unsigned char *ReadXbmBitmap(FILE *fp, char *datafile, int *w, int *h,
        XColor *colrs, Widget view);

unsigned char *ReadBitmap(char *datafile, int *w, int *h, XColor *colrs,
        int *bg, Widget view);

unsigned char *ReadGIF(FILE *fd, int *w, int *h, XColor *colrs, int *bg);

unsigned char *ReadXpm3Pixmap(FILE *fp, char *datafile, int *w, int *h, 
         XColor *colrs, int *bg, Widget view);
