/*
* xheader.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xheader.c
*
*
*/

void routines_html(Widget w, int item_no, XtPointer call_data);
void create_title(Widget w,XtPointer);
void title_name( Widget w, XtPointer, XmSelectionBoxCallbackStruct *cbs);
char *remove_title(XmTextPosition *left,XmTextPosition *right,HTMLED *);
void clear_title(Widget  w,XtPointer client_data,XtPointer call_data);
void create_paragraph(Widget w,HTMLED *);
void create_line_break(Widget w,HTMLED *he);
void create_hor_rule(Widget w,HTMLED *he);
void create_header(Widget w,HTMLED *);
void set_header(Widget w,XtPointer);
void create_undo(Widget w,HTMLED *he);
void verify_text(Widget tx, XtPointer , XmTextVerifyCallbackStruct *cbs);
void toggled(Widget w,XtPointer client_data, XtPointer call_data);

