/*
* xviewer.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xviewer.c
*
*
*/
Widget CreateHTMLwidget(Widget w,HTMLED *);
void Reload_HTML(Widget  w,XtPointer client_data, XtPointer call_data);
void CreateNewFrame(Widget w,HTMLED *he);
void CloseFrame(Widget w, HTMLED *he);
void anchor_call(Widget w, XtPointer client_data, XtPointer call_data);
char *getfile_href(char *nhref,HTMLED *he,char **directory);
char *get_title(Widget whtml);


void Create_Shell_Help(Widget w, XtPointer client_data, XtPointer call_data);
void BuildHelpMenu(Widget menubar,HTMLED *he);
Widget CreateHTMLwidget_help(Widget w,HTMLED *,char *);
void popdown_help(Widget w, XtPointer client_data, XtPointer call_data);
void anchor_help(Widget w, XtPointer client_data, XtPointer call_data);
String  read_help(void);

void Insert_html_frame(HTMLED *he);
void Delete_html_frame(HTMLED *he);
void Print_Frames(void);
void Exit_ASHE(Widget);
void exit_dialog(Widget);
void save_unmodified_files(Widget w);
int ask_save_file(Widget w,HTMLED *he);
XtEventHandler keypress_handler(Widget w, XtPointer client_data, XEvent *event,
				Boolean* bool);
ImageInfo *ImageResolve (Widget w, char *src);
void toggle_images(Widget w,XtPointer client_data,XtPointer call_data);
void toggle_tables(Widget w,XtPointer client_data,XtPointer call_data);
