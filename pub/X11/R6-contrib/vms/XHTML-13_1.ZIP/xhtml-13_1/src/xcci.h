
int ss_make_cci_connection(void);
int ss_show_next_url(char *url);
void CCI_HTML(Widget ,HTMLED *,XtPointer);
void port_name(Widget w,
		    XtPointer client_data,
		    XmSelectionBoxCallbackStruct *cbs);
void NET_HTML(Widget w,HTMLED *he,XtPointer call_data);
void load_net(Widget w,
		    XtPointer client_data,
		    XmSelectionBoxCallbackStruct *cbs);
void reload_net(Widget w,
		    XtPointer client_data,
		    XmSelectionBoxCallbackStruct *cbs);
