/*
* xmarkup.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xmarkup.c
*
*
*/

#define TOP_AL 0
#define MIDDLE_AL 1
#define BOTTOM_AL 2

void create_linker(Widget w,HTMLED *he);
void linker_name(Widget w,HTMLED * , XmSelectionBoxCallbackStruct *cbs);
void create_reference(Widget w,HTMLED *he);
void create_figure(Widget w,HTMLED *he);
void reference_name(Widget w,XtPointer ,XmSelectionBoxCallbackStruct *cbs);
void top_bottom(Widget w,XtPointer client_data, XtPointer call_data);
void image_name(Widget w, XtPointer ,XmSelectionBoxCallbackStruct *cbs);
void create_pre(Widget w,HTMLED *he);
void set_pre(Widget w,HTMLED *he);
void ismap_check(Widget w,XtPointer client_data, XtPointer call_data);
void align_cb(Widget w,XtPointer client_data, XtPointer call_data);

