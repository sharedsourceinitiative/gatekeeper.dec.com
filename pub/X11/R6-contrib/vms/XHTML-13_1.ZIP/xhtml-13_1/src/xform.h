/*
* xform.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xform.c
*
*
*/
typedef struct _menu_item{
   char *label;              /* the label for the item */
   WidgetClass *class;       /* pushbutton, label, separator... */
   char  mnemonic;           /* mnemonic, NULL if none */
   char *accelerator;        /* accelerator, NULL if none */
   char *accel_text;         /* to be converted to compound string */
   void (*callback)();       /* client_data for callback() */
   XtPointer callback_data;  /* client_data for callback() */
   struct _menu_item *subitems; /* pullright menu items, if not NULL */
} MenuItem;

Widget 
BuildPulldownMenu(Widget w, char *menu_title, char menu_mnemonic,
		 Boolean tear_off, MenuItem *items,HTMLED *he);


void form_name(Widget w, XtPointer client_data, XtPointer call_data);
void option_cb(Widget w, XtPointer client_data, XtPointer call_data);
void set_form(Widget w, XtPointer client_data, XtPointer call_data);
void form_text(Widget w, XtPointer client_data, XtPointer call_data);
XmString get_label_input(Widget w);
void ok_input_text(Widget w, XtPointer client_data, XtPointer call_data);
void check_number(Widget text_w, XtPointer client_data, XtPointer call_data);
void form_radio(Widget w, XtPointer client_data, XtPointer call_data);
void checked_input(Widget w, XtPointer client_data, XtPointer call_data);
void form_reset(Widget w, XtPointer client_data, XtPointer call_data);
void form_select(Widget w, XtPointer client_data, XtPointer call_data);
void ok_select(Widget w, XtPointer client_data, XtPointer call_data);
void multiple_select(Widget w, XtPointer client_data, XtPointer call_data);
void form_option(Widget w, XtPointer client_data, XtPointer call_data);
void selected_check(Widget w, XtPointer client_data, XtPointer call_data);
void ok_option(Widget w, XtPointer client_data, XtPointer call_data);
void form_textarea(Widget w, XtPointer client_data, XtPointer call_data);
void ok_textarea(Widget w, XtPointer client_data, XtPointer call_data);





