#define UFTP 1
#define ERROR_FTP 1
#define UHTTP 2
#define ERROR_HTTP 2
#define UMAILTO 3
#define ERROR_MAILTO 3
#define UFILE 4
#define ERROR_FILE 4
#define UGOPHER 5
#define ERROR_GOPHER 5
#define UNEWS 6
#define ERROR_NEWS 6
#define UTELNET 7
#define ERROR_TELNET 7
#define UWAIS 8
#define ERROR_WAIS 8
#define UNNTP 9
#define ERROR_NNTP 9
#define UPROSPERO 10
#define ERROR_PROSPERO 10
#define UNKNOWN 11

struct URL
{
   char *ws_protocol;
   char *ws_user;
   char *ws_password;
   char *ws_host;
   char *ws_port;
   char *ws_path;
   char *ws_name;
   char *ws_aditional;
   char *ws_rest;
   char *wc_jump;
   int protocol;
 };

typedef struct URL GURL;


void initialize_url(GURL *url);
int recognize_url(char *furl,GURL *url);
void print_url(GURL *url);
void delete_url(GURL *url);

char * suppress_dots(char *file);
char *getdirectory (char *fname);
char *get_url_file(HTMLED *he,char *url_rel,String directory,int *isfile);
String binding_relative_url(String url_rel,HTMLED *he,String directory,int *);
void strip_href(char *ohref,char **href, char**name);
