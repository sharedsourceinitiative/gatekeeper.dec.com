/*
* xstyles.h - (c) 1994 Copyright by John R. Punin
*
* Routine Declarations of the source file xstyles.c
*
*
*/

void routines_styles(Widget w, int item_no, XtPointer call_data);
void routines_lists(Widget w, int item_no, XtPointer call_data);
void set_style(Widget w, XtPointer,XtPointer);
void Command_text(enum commands command,char *sl,char *sr);
XmString Initial_text(int item_no,enum commands *command);
void set_definition_list(Widget w,HTMLED *);
void set_definition_entry(Widget w,HTMLED *);
void set_simple_list(Widget w,int item_no,HTMLED *);
void set_simple_entry(Widget w,HTMLED *);
XmString Initial_list(int item_no,enum commands *command);
void ChangeInsertionpoint(enum commands command,XmTextPosition left,HTMLED *);
void routines_carac(Widget w, int item_no, XtPointer call_data);
char * get_character(int item_no);
void BuildCharactersMenu(Widget menubar, HTMLED *he);







