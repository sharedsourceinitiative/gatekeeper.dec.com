extern PortDescriptor *NetClientConnect();
extern int NetWrite();
extern int NetIsThereInput();
extern int NetRead();
extern void NetCloseConnection();
extern char *NetReturnAddress();

#ifdef VMS
#ifdef __DECC
#if __DECC_VER < 50200000

#define NBBY    8               /* number of bits in a byte */

#ifndef FD_SETSIZE
#define FD_SETSIZE      256
#endif

#ifndef _FD_MASK_
#define _FD_MASK_
typedef long    fd_mask;
#endif /*_FD_MASK_*/

#define NFDBITS (sizeof(fd_mask) * NBBY)        /* bits per mask */
#ifndef howmany
#define howmany(x, y)   (((x)+((y)-1))/(y))
#endif

typedef struct fd_set {
        fd_mask fds_bits[howmany(FD_SETSIZE, NFDBITS)];
} fd_set;

#define FD_ZERO(p)      bzero((char *)(p), sizeof(*(p)))
#define FD_SET(n, p)    ((p)->fds_bits[(n)/NFDBITS] |= (1 << ((n) % NFDBITS)))

#endif  /* __DECC_VER */
#endif  /* __DECC */
#endif  /* VMS */
