char *dateString = "Sat Nov 30 16:41:16 CET 1996";
char *whoString = "pmoreau";
char *machineString = "OpenVMS_AXP SUBAXP  V6.2-1H3 AlphaStation_255_4/232 Alpha";
int buildNum = 0;
