#define O_RDONLY	0x00
#define O_WRONLY	0x01
#define O_RDWR		0x02
#define O_NDELAY	0x04
#define O_NOWAIT	0x04
#define O_APPEND	0x08
#define O_CREAT		0x200
#define O_TRUNC		0x400
#define O_EXCL		0x800

#define	L_SET		0x0
#define	L_INCR		0x1
#define	L_XTND		0x2

