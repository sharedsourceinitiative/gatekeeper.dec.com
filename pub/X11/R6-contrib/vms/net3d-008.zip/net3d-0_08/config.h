/* config.h
 *
 * configuration options file
 */
#ifndef config_h
#define config_h

#define DEBUG 0				/* Toggles debugging messages. */

#define SHADEDGROUND 1			/* Toggles the fake depth shading
					 * on the ground. */

#define NETDEBUG 0			/* Toggles display of incoming and
					 * outgoing network messages */

#define SEEDCHANCE 4			/* The higher SEEDCHANCE is, the
					 * lower the probability of fragment
					 * of a tree forming a new tree.  */

#define DISPLAYFPS 0			/* Toggles the display of frames
					 * per second */

#define DISPLAYCACHEINFO 0		/* Toggles the display of data about
					 * the sin and map caches. */

#define CPPPATH CPPCOMMAND		/* Full path to the c preprocessor
					 * used on your system. This should be
					 * found by Imake, but if not you will
					 * have to set it by hand. */

#define USEINLINES 1			/* If you are using gcc, this toggles
					 * the use of inline functions for
					 * matrix multiplication */

#endif

