/* netprotos.h
 *
 * prototypes for networking functions.
 */
#ifndef netprotos_h
#define netprotos_h

int OpenDest(void);
int OpenSend(char *);
void nprintf(int sock, char *fmt, ...);
char *ngets(int sock);
char *ngetw(int sock);

#endif

