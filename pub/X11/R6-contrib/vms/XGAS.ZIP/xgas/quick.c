char quick[]="\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
                                xgas Quick Help\n\
\n\
\n\
              MB 1 in chamber:   create 1 molecule\n\
              MB 2 in chamber:   create maximum number of molecules\n\
\n\
              run/pause:      toggle single step mode\n\
              step:           move one timestep\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
\n\
";
