extern liberte();
