/*

	types.h  definitions des types

*/

#ifndef _types_h
#define _types_h

typedef int board[10][8];

#define inf(a,b) (a<b?a:b)

#endif /* _types_h  */
