#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>

#ifdef VMS
#include <X11Xaw/Command.h>
#include <X11Xaw/Form.h>
#include <X11Xaw/Label.h>
#else
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Label.h>
#endif /* VMS */

#include "types.h"

board		play_board,calc_board;
int 	 	player,is_single,warn;
XtAppContext    app_context;
Widget          toplevel,wboard,interm,wplay,wreset,wmode,wmesg;
Widget	        wquit,wsingle,wtour,winfo;
Widget          tabl[10][8];
Pixmap	        pixtab[15];
Arg	        args[10];
Arg	        ar[10];
Cardinal        car;
Cardinal        card;
int             i,j,dump,coups;
char            buf[15];
int 		white_i,white_j;
int		black_i,black_j;
int 		mode;
int 		the_end;


void reset();
void play();
void compuplay();
void quit();
void setwarn();
void single();
