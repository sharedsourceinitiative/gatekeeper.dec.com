/* image_tcl.c: TCL interface to image routines.
**
** written and copyright (C) 1996 by Michael J. Gourlay
**
** No warrenties, express or implied.
*/

#include <tcl.h>
#include <tk.h>

#include "rgba_image.h"

extern Tcl_HashTable img_table;
extern int img_table_initF;

void createImageTag(RgbaImageT *imgP, char *tag);


int imageLoadCmd(ClientData client_data, Tcl_Interp *interp,
                int argc, char *argv[]);


int imageConvertCmd(ClientData client_data, Tcl_Interp *interp,
                    int argc, char *argv[]);
