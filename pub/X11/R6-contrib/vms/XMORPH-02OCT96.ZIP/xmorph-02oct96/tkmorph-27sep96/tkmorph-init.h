/* tkmorph-init.h */
#include <tcl.h>

int tkMorphInit(Tcl_Interp *interp);
