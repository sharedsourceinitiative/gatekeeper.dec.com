/* warp_tcl.h TCL interface to warp routines.
**
** Written and copyright (C) 1996 by Michael J. Gourlay
**
** PROVIDED AS IS.  NO WARRENTIES, EXPRESS OR IMPLIED.
*/

#include <tcl.h>



int warpCmd(ClientData client_data, Tcl_Interp *interp, int argc, char *argv[]);
