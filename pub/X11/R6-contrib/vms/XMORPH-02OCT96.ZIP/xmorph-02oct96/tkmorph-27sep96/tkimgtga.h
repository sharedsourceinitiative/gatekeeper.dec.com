/* tkImgTGA.h:  TCL/Tk Targa TGA photo image format ha
**
** written and copyright (C) 1996 by Michael J. Gourlay
**
** No warrenties, express or implied.
*/

void createTGAImageFormat(void);
