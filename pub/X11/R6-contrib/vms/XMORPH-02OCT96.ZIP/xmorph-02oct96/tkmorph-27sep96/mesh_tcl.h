/* mesh_tcl.h: TCL interface to mesh routines.
**
** written and copyright (C) 1996 by Michael J. Gourlay
**
** PROVIDED AS IS.  NO WARRENTIES, EXPRESS OR IMPLIED.
*/

#include <tcl.h>

extern Tcl_HashTable mesh_table;
extern int mesh_table_initF;


int meshLoadCmd(ClientData client_data, Tcl_Interp *interp,
		int argc, char *argv[]);

int meshValuesCmd(ClientData client_data, Tcl_Interp *interp, int argc, char *argv[]);
