/* mesh_diw.c -- mesh handling routines for DIW maps
**
** Written and Copyright (C) 1994, 1996 by Michael J. Gourlay
**
** NO WARRANTEES, EXPRESS OR IMPLIED.
*/

#include <stdio.h>
#include <stdlib.h>

#include "my_malloc.h"

#include "diw_map.h"
#include "file.h"
#include "mesh.h"
#include "mesh_diw.h"




/* ---------------------------------------------------------------------- */

/* reset_meshes : set image warp mesh to be a regularly spaced mesh
*/
void
reset_meshes(diw_map_t *diw_mapP)
{
  meshReset(&diw_mapP->mesh_src, diw_mapP->width, diw_mapP->height);
  meshReset(&diw_mapP->mesh_dst, diw_mapP->width, diw_mapP->height);
}
