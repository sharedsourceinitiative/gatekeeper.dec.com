/* mesh_diw.h -- mesh handling routines header for DIW maps
**
** Written and Copyright (C) 1994, 1996 by Michael J. Gourlay
**
** NO WARRANTEES, EXPRESS OR IMPLIED.
*/

#ifndef _MESH_DIW_H__INCLUDED_
#define _MESH_DIW_H__INCLUDED_

#include "diw_map.h"

extern void reset_meshes(diw_map_t *diw_mapP);

#endif /* _MESH_DIW_H__INCLUDED_ */
