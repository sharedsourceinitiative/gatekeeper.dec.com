/*
# X-BASED ABACUS
#
#  Abacus.h
#
###
#
#  Copyright (c) 1994 - 95	David Albert Bagley, bagleyd@source.asset.com
#
#                   All Rights Reserved
#
#  Permission to use, copy, modify, and distribute this software and
#  its documentation for any purpose and without fee is hereby granted,
#  provided that the above copyright notice appear in all copies and
#  that both that copyright notice and this permission notice appear in
#  supporting documentation, and that the name of the author not be
#  used in advertising or publicity pertaining to distribution of the
#  software without specific, written prior permission.
#
#  This program is distributed in the hope that it will be "useful",
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
*/

/* Public header file for Abacus */

#ifndef _XtAbacus_h
#define _XtAbacus_h

/***********************************************************************
 *
 * Abacus Widget
 *
 ***********************************************************************/

#define XtNselectCallback "selectCallback"
#define XtNbars "bars"
#define XtNspaces "spaces"
#define XtNbase "base"
#define XtNtopNumber "topNumber"
#define XtNtopOrient "topOrient"
#define XtNtopFactor "topFactor"
#define XtNbottomNumber "bottomNumber"
#define XtNbottomOrient "bottomOrient"
#define XtNbottomFactor "bottomFactor"
#define XtNbeadColor "beadColor"
#define XtNbuffer "Buffer"
#define XtCBars "Bars"
#define XtCSpaces "Spaces"
#define XtCBase "Base"
#define XtCTopNumber "TopNumber"
#define XtCTopFactor "TopFactor"
#define XtCTopOrient "TopOrient"
#define XtCBottomNumber "BottomNumber"
#define XtCBottomFactor "BottomFactor"
#define XtCBottomOrient "BottomOrient"
#define XtCBeadColor "BeadColor"
#define XtCBuffer "Buffer"

typedef struct _AbacusClassRec *AbacusWidgetClass;
typedef struct _AbacusRec *AbacusWidget;

extern WidgetClass abacusWidgetClass;

typedef struct {
  XEvent *event;
  char buffer[40];
} abacusCallbackStruct;

#endif _XtAbacus_h
/* DON'T ADD STUFF AFTER THIS #endif */
